[CmdletBinding()]
param(
    [string]$Python = "py",
    [ValidateSet("3.12", "3.13")][string]$PythonVersion = "3.12",
    [switch]$OneFile,
    [switch]$Console,
    [switch]$SkipTests,
    [switch]$SkipInstall
)

$ErrorActionPreference = "Stop"
$projectRoot = $PSScriptRoot
$venvPath = Join-Path $projectRoot ".venv-build"
$venvPython = Join-Path $venvPath "Scripts\python.exe"
$previousOneFile = $env:NCSTUDIO_ONEFILE
$previousConsole = $env:NCSTUDIO_CONSOLE

Push-Location -LiteralPath $projectRoot
try {
    if (-not (Test-Path -LiteralPath $venvPython)) {
        if ($Python -eq "py") {
            & $Python "-$PythonVersion" -m venv $venvPath
        } else {
            & $Python -m venv $venvPath
        }
        if ($LASTEXITCODE -ne 0) { throw "Failed to create the build environment." }
    }
    & $venvPython -c "import struct, sys; assert (3,12) <= sys.version_info[:2] < (3,14) and struct.calcsize('P') == 8, 'Python 3.12/3.13 x64 is required'"
    if ($LASTEXITCODE -ne 0) { throw "Unsupported Python version or architecture." }

    if (-not $SkipInstall) {
        & $venvPython -m pip install --upgrade pip
        if ($LASTEXITCODE -ne 0) { throw "pip setup failed." }
        $lockPath = Join-Path $projectRoot "requirements-lock.txt"
        if (Test-Path -LiteralPath $lockPath) {
            & $venvPython -m pip install -r $lockPath
        } else {
            & $venvPython -m pip install -r requirements-dev.txt
        }
        if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed." }
    }

    $checkDir = Join-Path $projectRoot "work\build-checks"
    New-Item -ItemType Directory -Path $checkDir -Force | Out-Null
    if (-not $SkipTests) {
        & $venvPython -m pytest -q
        if ($LASTEXITCODE -ne 0) { throw "Tests failed. Build stopped." }
        & $venvPython -m ncgeotiff --self-test --report (Join-Path $checkDir "source-smoke.json")
        if ($LASTEXITCODE -ne 0) { throw "Source self-test failed. Build stopped." }
    }

    $env:NCSTUDIO_ONEFILE = if ($OneFile) { "1" } else { "0" }
    $env:NCSTUDIO_CONSOLE = if ($Console) { "1" } else { "0" }
    & $venvPython -m PyInstaller --noconfirm --clean NCStudio.spec
    if ($LASTEXITCODE -ne 0) { throw "PyInstaller build failed." }

    $exePath = if ($OneFile) {
        Join-Path $projectRoot "dist\NCStudio.exe"
    } else {
        Join-Path $projectRoot "dist\NCStudio\NCStudio.exe"
    }
    $smokeReport = Join-Path $checkDir "frozen-smoke.json"
    # Remove only an old report, so a previous successful run cannot mask failure.
    if (Test-Path -LiteralPath $smokeReport) {
        Remove-Item -LiteralPath $smokeReport
    }
    $process = Start-Process -FilePath $exePath -ArgumentList @(
        "--self-test", "--report", ('"{0}"' -f $smokeReport)
    ) -PassThru -WindowStyle Hidden
    if (-not $process.WaitForExit(120000)) {
        $process.Kill()
        $process.WaitForExit()
        throw "Frozen GUI self-test timed out after 120 seconds."
    }
    if ($process.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $smokeReport)) {
        throw "Frozen application self-test failed. Review $smokeReport"
    }
    Write-Host "Build complete: $exePath"
    Write-Host "Frozen self-test report: $smokeReport"
    if (-not $OneFile) {
        Write-Host "Distribute the whole dist\NCStudio folder, including _internal."
    }
} finally {
    $env:NCSTUDIO_ONEFILE = $previousOneFile
    $env:NCSTUDIO_CONSOLE = $previousConsole
    Pop-Location
}
