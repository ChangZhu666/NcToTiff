# Windows 打包说明

推荐使用 Python 3.12 x64 或 Python 3.13 x64。Python 3.12 的第三方 GIS wheel 覆盖更稳，构建脚本默认选择 3.12。

## 一键构建

在项目根目录运行：

```powershell
.\build.ps1
```

成功后生成：

```text
dist\NCStudio\NCStudio.exe
```

发布时请分发整个 `dist\NCStudio` 文件夹。

## 单文件构建

```powershell
.\build.ps1 -OneFile
```

成功后生成：

```text
dist\NCStudio.exe
```

单文件启动较慢，体积也更大，但用户只需要一个 exe。

## 使用指定 Python

```powershell
.\build.ps1 -Python C:\Python312\python.exe
```

## 构建过程

脚本会执行以下步骤：

1. 创建 `.venv-build`。
2. 安装 `requirements-dev.txt` 或 `requirements-lock.txt`。
3. 运行 pytest。
4. 运行源码自检。
5. 调用 PyInstaller。
6. 运行打包后 exe 的自检。

自检报告写入：

```text
work\build-checks\source-smoke.json
work\build-checks\frozen-smoke.json
```

从 1.0.5 起，自检会在实际 Qt 事件循环里触发拖入文件的信号，等待元数据显示，再点击运行按钮转换小样本并核验 GeoTIFF。仅调用 `inspect_file` 或仅创建窗口不能验证后台任务是否正常启动。

对用户文件单独验证打包后的界面分析流程（只分析，不导出）：

```powershell
$guiCheck = Start-Process -FilePath .\dist\NCStudio\NCStudio.exe -ArgumentList '--gui-self-test "C:\data\sample.nc" --report "gui-report.json"' -PassThru -WindowStyle Hidden
if (-not $guiCheck.WaitForExit(120000)) { $guiCheck.Kill(); throw 'GUI verification timed out.' }
Get-Content gui-report.json
```

报告应包含版本 `1.0.5`、`ok: true`、元数据以及日志中的“元数据分析完成”。

## 常见问题

如果打包后的 exe 启动后提示找不到 GDAL、PROJ 或 netCDF 相关库，先确认使用的是官方 Windows wheel，并重新安装依赖。`NCStudio.spec` 已收集 rasterio、pyproj 和 netCDF4 的数据文件、动态库和 delvewheel DLL 目录。

如果中文日志在控制台中显示乱码，通常是 PowerShell 编码页问题，不影响 GUI 或 JSON 报告。可以运行：

```powershell
chcp 65001
```

如果输出目录路径很长，Windows 可能拒绝创建最终 GeoTIFF。工具会提示选择更短的输出路径。
