# 架构方案

NC Studio 分为三层：

1. PySide6 桌面界面层：`ncgeotiff/gui.py`
2. NetCDF 分析与 GeoTIFF 转换引擎：`ncgeotiff/engine.py`
3. 命令行、自检和打包入口：`ncgeotiff/__main__.py`、`ncgeotiff/selftest.py`、`launcher.py`

## 界面

主界面采用浅灰背景、白色面板、8px 左右圆角和蓝色主按钮，整体接近 macOS 的克制风格。顶部是拖拽区，支持 `.nc/.nc4/.cdf` 文件；拖拽悬停时显示蓝色高亮，文件选中后显示绿色边框和绝对路径。

中部左侧是变量概览，右侧是四个标签页：

- 变量：变量名、单位、维度、形状、是否可转换和说明。
- 空间与时间：坐标系、分辨率、范围、时间摘要和坐标变量。
- 全局属性：文件级属性 JSON。
- 日志：分析、转换、跳过和错误消息。

底部提供输出目录输入框、目录选择按钮、运行按钮、取消按钮和进度条。

耗时任务在 QThread 中执行，界面线程只接收信号并刷新状态。取消操作通过 `threading.Event` 传给转换引擎。

主窗口用 `self._worker` 和 `self._thread` 持有后台任务。Qt 信号连接不负责保留 Python 创建的任务对象，不能只将 worker 放在局部变量中。结果或错误先传回主线程，待 `thread.finished` 后统一释放引用并更新界面；此时才允许启动下一项任务。后台运行时关闭窗口会等任务结束再关闭，避免销毁仍在运行的线程。

## 数据流程

分析流程：

1. 校验文件扩展名和路径。
2. 使用 xarray + netCDF4 打开数据集，并启用 CF 坐标解码。
3. 读取维度、全局属性、坐标变量和数据变量。
4. 对每个变量识别空间坐标、坐标系、规则网格、时间维和额外维度。
5. 返回 `DatasetInfo`，供 GUI 和 CLI 展示。

转换流程：

1. 重新分析文件，选出可转换变量。
2. 按时间维和额外非空间维度展开成导出任务。
3. 每个任务以窗口方式分块读取并写入 GeoTIFF。
4. 先写入 `.partial.tif` 临时文件，成功后原子发布为最终文件。
5. 写出 JSON manifest，记录输入文件、元数据、输出文件、错误和跳过项。

## CF 兼容策略

引擎优先使用 CF 语义：

- 坐标识别使用 `standard_name`、`units`、`axis` 和常见名称。
- CRS 识别使用 `grid_mapping`、`crs_wkt`、`spatial_ref`、EPSG 和 pyproj CF 转换。
- 时间识别使用坐标名、`standard_name=time`、`axis=T` 和 `units since`。
- 经纬度缺少显式 CRS 时按 EPSG:4326 处理，并记录提示。

当前只导出规则直角网格。曲线网格、非等距网格和旋转坐标如果直接套仿射变换，容易让科学数据错位，所以会被跳过。

## 参考

- xarray open_dataset: https://docs.xarray.dev/en/stable/generated/xarray.open_dataset.html
- xarray CF decoding: https://docs.xarray.dev/en/stable/generated/xarray.decode_cf.html
- pyproj CF CRS: https://pyproj4.github.io/pyproj/stable/build_crs_cf.html
- rasterio windowed read/write: https://rasterio.readthedocs.io/en/stable/topics/windowed-rw.html
- PySide6 QThread: https://doc.qt.io/qtforpython-6/PySide6/QtCore/QThread.html
- PyInstaller hooks: https://pyinstaller.org/en/latest/hooks.html
