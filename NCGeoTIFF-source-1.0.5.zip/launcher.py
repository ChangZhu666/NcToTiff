"""Absolute-import entry point for PyInstaller."""

from ncgeotiff.__main__ import main


if __name__ == "__main__":
    raise SystemExit(main())
