"""Create a compact CF demo: temperature, precipitation, NDVI and elevation.

Usage: python examples/create_demo.py --output examples/demo.nc
"""

from argparse import ArgumentParser
from pathlib import Path

import numpy as np
import xarray as xr


def create_demo(output: Path) -> Path:
    # Coordinates describe cell centres; latitude deliberately runs south to north.
    latitude = np.arange(24, 40.00001, 0.2, dtype="float64")
    longitude = np.arange(105, 122.00001, 0.2, dtype="float64")
    lon, lat = np.meshgrid(longitude, latitude)
    time = np.array(["2024-06-01", "2024-06-02", "2024-06-03"], dtype="datetime64[ns]")
    mountain = np.exp(-((lon - 111) ** 2 / 16 + (lat - 32) ** 2 / 12))
    elevation = 120 + 2600 * mountain + 80 * np.sin(lon) * np.cos(lat)
    temperature = np.stack([30 - 0.45 * (lat - 24) - elevation * 0.004 + day * 1.2 for day in range(3)])
    precipitation = np.stack([35 * np.exp(-((lon - 113 - day) ** 2 / 6 + (lat - 30 - day * 0.5) ** 2 / 8)) for day in range(3)])
    ndvi = np.stack([np.clip(0.58 + 0.24 * np.sin((lon - 105) / 4) * np.cos((lat - 24) / 5) + day * 0.025, 0, 1) for day in range(3)])
    missing = ((lon - 119) ** 2 + (lat - 27) ** 2) < 2.5
    temperature[:, missing] = np.nan
    precipitation[:, missing] = np.nan
    ndvi[:, missing] = np.nan
    ds = xr.Dataset(
        data_vars={
            "temperature": (("time", "latitude", "longitude"), temperature, {"standard_name": "air_temperature", "long_name": "Daily air temperature", "units": "degree_Celsius"}),
            "precipitation": (("time", "latitude", "longitude"), precipitation.astype("float32"), {"long_name": "Daily precipitation", "units": "mm"}),
            "NDVI": (("time", "latitude", "longitude"), ndvi.astype("float32"), {"long_name": "Normalized difference vegetation index", "units": "1"}),
            "elevation": (("latitude", "longitude"), elevation.astype("float32"), {"standard_name": "surface_altitude", "long_name": "Synthetic elevation", "units": "m"}),
            "station_count": ("time", np.array([32, 35, 34], dtype="int16"), {"long_name": "Non-spatial variable: skipped on export", "units": "1"}),
        },
        coords={
            "latitude": ("latitude", latitude, {"standard_name": "latitude", "long_name": "Latitude", "units": "degrees_north", "axis": "Y"}),
            "longitude": ("longitude", longitude, {"standard_name": "longitude", "long_name": "Longitude", "units": "degrees_east", "axis": "X"}),
            "time": ("time", time, {"standard_name": "time", "axis": "T"}),
        },
        attrs={
            "Conventions": "CF-1.8",
            "title": "NCGeoTIFF synthetic weather and vegetation demo",
            "summary": "Three days of synthetic data; 10 spatial layers, one non-spatial variable, and a deliberate missing-data region.",
            "source": "Deterministic mathematical simulation; not observational data",
            "institution": "NCGeoTIFF example generator",
            "geospatial_lat_min": 24.0,
            "geospatial_lat_max": 40.0,
            "geospatial_lon_min": 105.0,
            "geospatial_lon_max": 122.0,
        },
    )
    output = output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    encoding = {
        "temperature": {"dtype": "int16", "scale_factor": 0.01, "add_offset": 0.0, "_FillValue": -32768, "zlib": True},
        "precipitation": {"dtype": "float32", "_FillValue": -9999.0, "zlib": True},
        "NDVI": {"dtype": "float32", "_FillValue": -9999.0, "zlib": True},
        "elevation": {"dtype": "float32", "zlib": True},
        "time": {"calendar": "standard", "units": "days since 2024-06-01"},
    }
    ds.to_netcdf(output, engine="netcdf4", encoding=encoding)
    ds.close()
    return output


if __name__ == "__main__":
    parser = ArgumentParser(description="生成用于 NCGeoTIFF 演示和验收的 CF NetCDF 文件（非实测数据）。")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "demo.nc", help="输出 .nc 文件路径")
    arguments = parser.parse_args()
    destination = create_demo(arguments.output)
    print(f"已生成：{destination}")
    print("包含 3 天的温度、降水、NDVI 和 1 层高程，共 10 个可导出图层。")
