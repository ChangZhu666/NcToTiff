[CmdletBinding()]
param(
    [string]$Python = "py",
    [ValidateSet("3.12", "3.13")][string]$PythonVersion = "3.12",
    [switch]$Install,
    [Parameter(ValueFromRemainingArguments = $true)][string[]]$AppArguments
)

$ErrorActionPreference = "Stop"
$projectRoot = $PSScriptRoot
$venvPath = Join-Path $projectRoot ".venv"
$venvPython = Join-Path $venvPath "Scripts\python.exe"
Push-Location -LiteralPath $projectRoot
try {
    if (-not (Test-Path -LiteralPath $venvPython)) {
        if ($Python -eq "py") {
            & $Python "-$PythonVersion" -m venv $venvPath
        } else {
            & $Python -m venv $venvPath
        }
        if ($LASTEXITCODE -ne 0) { throw "Failed to create the application environment." }
        $Install = $true
    }
    & $venvPython -c "import struct, sys; assert (3,12) <= sys.version_info[:2] < (3,14) and struct.calcsize('P') == 8, 'Python 3.12/3.13 x64 is required'"
    if ($LASTEXITCODE -ne 0) { throw "Unsupported Python version or architecture." }
    if ($Install) {
        & $venvPython -m pip install -r requirements.txt
        if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed." }
    }
    & $venvPython -m ncgeotiff @AppArguments
    if ($LASTEXITCODE -ne 0) { throw "NC Studio exited with code $LASTEXITCODE." }
} finally {
    Pop-Location
}
