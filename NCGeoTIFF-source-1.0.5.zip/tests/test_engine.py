"""Integration checks against real NetCDF and GeoTIFF files.

All datasets and exports are isolated in pytest's temporary directories.
"""

from pathlib import Path
import json
import re

import cftime
import numpy as np
import pytest
import rasterio
from pyproj import CRS
from rasterio.transform import from_origin
import xarray as xr

from ncgeotiff.engine import NetCDFError, export_file, inspect_file


def geographic_dataset(values=None, *, lat=None, lon=None, name="temperature"):
    lat = np.array([10.0, 20.0, 30.0]) if lat is None else np.asarray(lat)
    lon = np.array([90.0, 100.0, 110.0, 120.0]) if lon is None else np.asarray(lon)
    if values is None:
        values = np.arange(lat.size * lon.size, dtype="float32").reshape(lat.size, lon.size)
    return xr.Dataset(
        {name: (("lat", "lon"), values, {"units": "K", "long_name": "Surface temperature"})},
        coords={
            "lat": ("lat", lat, {"standard_name": "latitude", "units": "degrees_north", "axis": "Y"}),
            "lon": ("lon", lon, {"standard_name": "longitude", "units": "degrees_east", "axis": "X"}),
        },
        attrs={"Conventions": "CF-1.8", "title": "Synthetic integration data"},
    )


def save(ds, path, **kwargs):
    ds.to_netcdf(path, engine="netcdf4", **kwargs)
    return path


def variable(info, name="temperature"):
    return next(item for item in info.variables if item.name == name)


def assert_clean_export(result, directory):
    expected = {Path(item).resolve() for item in result.files}
    actual = {item.resolve() for item in directory.glob("*.tif")}
    assert actual == expected
    assert not list(directory.rglob("*.part"))
    assert not list(directory.rglob("*.tmp"))
    assert not list(directory.rglob("*.partial.*"))


def test_metadata_absolute_path_global_attributes_and_grid(tmp_path, monkeypatch):
    source = save(geographic_dataset(), tmp_path / "metadata.nc")
    monkeypatch.chdir(tmp_path)
    info = inspect_file("metadata.nc")
    assert Path(info.path) == source.resolve()
    assert info.size_bytes > 0
    assert info.dimensions["lat"] == 3
    assert info.dimensions["lon"] == 4
    assert info.global_attributes["Conventions"] == "CF-1.8"
    temp = variable(info)
    assert temp.units == "K"
    assert temp.spatial
    assert temp.layer_count == 1
    assert temp.grid is not None
    assert temp.grid.resolution == pytest.approx((10, 10))
    assert temp.grid.bounds == pytest.approx((85, 5, 125, 35))


def test_orientation_transposed_dimensions_bounds_and_pixel_centres(tmp_path):
    values = np.arange(12, dtype="float32").reshape(3, 4)
    ds = geographic_dataset(values, lon=[120, 110, 100, 90])
    ds["temperature"] = ds.temperature.transpose("lon", "lat")
    source = save(ds, tmp_path / "orientation.nc")
    result = export_file(source, tmp_path / "out")
    assert not result.errors
    assert len(result.files) == 1
    with rasterio.open(result.files[0]) as tif:
        assert tif.crs == rasterio.crs.CRS.from_epsg(4326)
        assert tif.transform == from_origin(85, 35, 10, 10)
        assert tuple(tif.bounds) == pytest.approx((85, 5, 125, 35))
        assert tif.xy(0, 0) == pytest.approx((90, 30))
        assert tif.xy(2, 3) == pytest.approx((120, 10))
        np.testing.assert_array_equal(tif.read(1), values[::-1, ::-1])


def test_time_and_extra_dimensions_export_each_layer(tmp_path):
    ds = geographic_dataset()
    values = np.stack([np.full((3, 4), value, dtype="float32") for value in [10, 20, 30, 40]])
    ds["temperature"] = (("time", "level", "lat", "lon"), values.reshape(2, 2, 3, 4))
    ds = ds.assign_coords(
        time=("time", np.array(["2024-01-01", "2024-01-02"], dtype="datetime64[ns]")),
        level=("level", [850, 500], {"units": "hPa", "axis": "Z"}),
    )
    source = save(ds, tmp_path / "layers.nc")
    assert variable(inspect_file(source)).layer_count == 4
    result = export_file(source, tmp_path / "out")
    assert not result.errors
    assert len(set(result.files)) == 4
    actual = []
    for filename in result.files:
        assert "temperature" in Path(filename).name
        assert "2024" in Path(filename).name
        with rasterio.open(filename) as tif:
            actual.append(float(tif.read(1)[0, 0]))
    assert sorted(actual) == [10, 20, 30, 40]


def test_packed_scale_offset_and_fill_are_decoded_once(tmp_path):
    values = np.array([[273.15, 280.25, np.nan, 301.75], [285.25, 285.35, 285.45, 285.55], [270.15, 270.25, 270.35, 270.45]], dtype="float64")
    source = save(
        geographic_dataset(values), tmp_path / "packed.nc",
        encoding={"temperature": {"dtype": "int16", "scale_factor": 0.1, "add_offset": 273.15, "_FillValue": -32768}},
    )
    with xr.open_dataset(source, engine="netcdf4") as decoded:
        expected = decoded.temperature.values[::-1]
    result = export_file(source, tmp_path / "out")
    assert not result.errors
    with rasterio.open(result.files[0]) as tif:
        actual = tif.read(1, masked=True)
        np.testing.assert_allclose(actual.filled(np.nan), expected, atol=1e-5, equal_nan=True)
        assert actual.mask.sum() == 1


def test_cftime_360_day_retains_non_gregorian_date(tmp_path):
    ds = geographic_dataset().expand_dims(time=[cftime.Datetime360Day(2001, 2, 30), cftime.Datetime360Day(2001, 3, 1)])
    source = save(ds, tmp_path / "calendar.nc")
    info = inspect_file(source)
    assert variable(info).layer_count == 2
    result = export_file(source, tmp_path / "out")
    assert not result.errors
    assert len(result.files) == 2
    assert any("20010230" in re.sub(r"\D", "", Path(item).name) for item in result.files)


def test_projected_cf_mapping_and_kilometre_coordinates(tmp_path):
    crs = CRS.from_epsg(32650)
    values = np.arange(6, dtype="float32").reshape(2, 3)
    ds = xr.Dataset(
        {"temperature": (("y", "x"), values, {"grid_mapping": "utm", "units": "K"}), "utm": ((), 0, crs.to_cf())},
        coords={
            "x": ("x", [400.0, 401.0, 402.0], {"standard_name": "projection_x_coordinate", "units": "km", "axis": "X"}),
            "y": ("y", [3500.0, 3501.0], {"standard_name": "projection_y_coordinate", "units": "km", "axis": "Y"}),
        },
        attrs={"Conventions": "CF-1.8"},
    )
    source = save(ds, tmp_path / "utm.nc")
    temp = variable(inspect_file(source))
    assert temp.spatial, temp.reason
    assert temp.grid.resolution == pytest.approx((1000, 1000))
    result = export_file(source, tmp_path / "out", variable_names=["temperature"])
    assert not result.errors
    with rasterio.open(result.files[0]) as tif:
        assert tif.crs == rasterio.crs.CRS.from_epsg(32650)
        assert tif.transform == from_origin(399500, 3501500, 1000, 1000)
        assert tif.xy(0, 0) == pytest.approx((400000, 3501000))
        np.testing.assert_array_equal(tif.read(1), values[::-1])


def test_projected_coordinates_without_crs_are_not_assumed_wgs84(tmp_path):
    ds = xr.Dataset(
        {"temperature": (("y", "x"), np.ones((2, 3)))},
        coords={
            "x": ("x", [400000, 401000, 402000], {"standard_name": "projection_x_coordinate", "units": "m"}),
            "y": ("y", [3500000, 3501000], {"standard_name": "projection_y_coordinate", "units": "m"}),
        },
    )
    source = save(ds, tmp_path / "unknown_crs.nc")
    temp = variable(inspect_file(source))
    assert not temp.spatial
    assert temp.reason.strip()
    with pytest.raises(NetCDFError) as error:
        export_file(source, tmp_path / "out")
    assert str(error.value).strip()
    assert not list((tmp_path / "out").glob("*.tif"))


@pytest.mark.parametrize("kind", ["nonuniform", "curvilinear"])
def test_unsupported_grids_have_visible_reason(tmp_path, kind):
    if kind == "nonuniform":
        ds = geographic_dataset(lon=[90, 100, 111, 120])
    else:
        ds = xr.Dataset(
            {"temperature": (("row", "col"), np.ones((2, 3)))},
            coords={
                "latitude": (("row", "col"), [[10, 10.1, 10.2], [11, 11.1, 11.2]], {"standard_name": "latitude", "units": "degrees_north"}),
                "longitude": (("row", "col"), [[90, 91, 92], [90.1, 91.1, 92.1]], {"standard_name": "longitude", "units": "degrees_east"}),
            },
        )
    source = save(ds, tmp_path / f"{kind}.nc")
    temp = variable(inspect_file(source))
    assert not temp.spatial
    assert temp.reason.strip()
    with pytest.raises(NetCDFError) as error:
        export_file(source, tmp_path / "out")
    assert str(error.value).strip()
    assert not list((tmp_path / "out").glob("*.tif"))


def test_auxiliary_one_dimensional_lat_lon_coordinates(tmp_path):
    ds = xr.Dataset(
        {"temperature": (("row", "col"), np.arange(6).reshape(2, 3))},
        coords={
            "latitude": ("row", [10, 11], {"standard_name": "latitude", "units": "degrees_north"}),
            "longitude": ("col", [100, 101, 102], {"standard_name": "longitude", "units": "degrees_east"}),
        },
    )
    source = save(ds, tmp_path / "auxiliary.nc")
    temp = variable(inspect_file(source))
    assert temp.spatial, temp.reason
    result = export_file(source, tmp_path / "out")
    assert not result.errors
    with rasterio.open(result.files[0]) as tif:
        assert tif.xy(0, 0) == pytest.approx((100, 11))
        np.testing.assert_array_equal(tif.read(1), [[3, 4, 5], [0, 1, 2]])


def test_zero_to_360_longitude_is_preserved_and_warned(tmp_path):
    source = save(geographic_dataset(lon=[270, 280, 290, 300]), tmp_path / "longitude.nc")
    info = inspect_file(source)
    temp = variable(info)
    assert temp.spatial, temp.reason
    assert info.warnings or temp.grid.warnings
    result = export_file(source, tmp_path / "out")
    assert not result.errors
    with rasterio.open(result.files[0]) as tif:
        assert tif.xy(0, 0)[0] == pytest.approx(270)
        assert tif.bounds.left == pytest.approx(265)


def test_repeated_export_never_overwrites_previous_output(tmp_path):
    source = save(geographic_dataset(), tmp_path / "repeat.nc")
    out = tmp_path / "out"
    first = export_file(source, out)
    assert not first.errors
    original = {Path(item): Path(item).read_bytes() for item in first.files}
    second = export_file(source, out)
    assert not second.errors
    assert len(second.files) == 1
    assert set(first.files).isdisjoint(second.files)
    for filename, contents in original.items():
        assert filename.read_bytes() == contents
    assert len(list(out.glob("*.tif"))) == 2


def test_timeless_and_special_character_names_are_windows_safe(tmp_path):
    source = save(geographic_dataset(name="温度:2米?*"), tmp_path / "names.nc")
    result = export_file(source, tmp_path / "out")
    assert not result.errors
    assert len(result.files) == 1
    name = Path(result.files[0]).name
    assert not any(char in name for char in '<>:"/\\|?*')
    assert not Path(name).stem.endswith((" ", "."))
    assert len(name.split("-")) >= 3
    with rasterio.open(result.files[0]) as tif:
        assert tif.count == 1


def test_float64_precision_is_not_silently_reduced(tmp_path):
    values = np.full((3, 4), 1 + 2 ** -40, dtype="float64")
    source = save(geographic_dataset(values), tmp_path / "precision.nc")
    result = export_file(source, tmp_path / "out")
    assert not result.errors
    with rasterio.open(result.files[0]) as tif:
        assert tif.dtypes == ("float64",)
        np.testing.assert_array_equal(tif.read(1), values[::-1])


def test_integer_samples_preserve_exact_values(tmp_path):
    values = (np.arange(12).reshape(3, 4) + 2**30).astype("int32")
    source = save(geographic_dataset(values), tmp_path / "integer.nc")
    result = export_file(source, tmp_path / "out")
    assert not result.errors
    with rasterio.open(result.files[0]) as tif:
        np.testing.assert_array_equal(tif.read(1), values[::-1])


def test_cancel_after_completed_layer_retains_valid_files_and_manifest(tmp_path):
    ds = geographic_dataset().expand_dims(time=np.array(["2024-01-01", "2024-01-02", "2024-01-03"], dtype="datetime64[ns]"))
    source = save(ds, tmp_path / "cancel.nc")
    stop = False
    events = []

    def progress(done, total, message):
        nonlocal stop
        events.append((done, total, message))
        if done >= 1:
            stop = True

    out = tmp_path / "out"
    result = export_file(source, out, progress=progress, cancel=lambda: stop)
    assert result.cancelled
    assert not result.errors
    assert len(result.files) == 1
    assert events[0][:2] == (0, 3)
    with rasterio.open(result.files[0]) as tif:
        np.testing.assert_array_equal(tif.read(1), ds.temperature.values[0, ::-1])
    manifest = json.loads(Path(result.manifest_path).read_text(encoding="utf-8"))
    assert manifest["cancelled"] is True
    assert manifest["completed_layers"] == 1
    assert_clean_export(result, out)


def test_cancel_during_layer_removes_partial_tiff(tmp_path):
    # More than one I/O block makes cancellation exercise an open output file.
    ds = geographic_dataset(
        np.ones((600, 600), dtype="float32"),
        lat=np.linspace(-30, 30, 600), lon=np.linspace(80, 120, 600),
    )
    source = save(ds, tmp_path / "partial_cancel.nc")
    stop = False
    callbacks = 0

    def progress(done, total, message):
        nonlocal stop, callbacks
        callbacks += 1
        if callbacks > 1:
            stop = True

    out = tmp_path / "out"
    result = export_file(source, out, progress=progress, cancel=lambda: stop)
    assert result.cancelled
    assert not result.errors
    assert not result.files
    assert callbacks >= 2
    assert_clean_export(result, out)


def test_failed_layer_is_cleaned_and_later_layer_still_exports(tmp_path, monkeypatch):
    ds = geographic_dataset().expand_dims(time=np.array(["2024-01-01", "2024-01-02"], dtype="datetime64[ns]"))
    source = save(ds, tmp_path / "partial_failure.nc")
    original_open = rasterio.open
    injected = False

    def failing_first_writer(path, mode="r", **kwargs):
        nonlocal injected
        if mode == "w" and not injected:
            injected = True
            with original_open(path, mode, **kwargs):
                pass
            raise OSError("simulated disk write failure")
        return original_open(path, mode, **kwargs)

    monkeypatch.setattr(rasterio, "open", failing_first_writer)
    events, logs = [], []
    out = tmp_path / "out"
    result = export_file(source, out, progress=lambda *args: events.append(args), log=logs.append)
    assert injected
    assert not result.cancelled
    assert len(result.errors) == 1
    assert "simulated disk write failure" in result.errors[0]
    assert len(result.files) == 1
    assert events[-1][:2] == (2, 2)
    assert any("simulated disk write failure" in item for item in logs)
    with rasterio.open(result.files[0]) as tif:
        np.testing.assert_array_equal(tif.read(1), ds.temperature.values[1, ::-1])
    assert_clean_export(result, out)


def test_variable_selection_and_nonspatial_skip_are_reported(tmp_path):
    ds = geographic_dataset()
    ds["elevation"] = (("lat", "lon"), np.ones((3, 4), dtype="float32"), {"units": "m"})
    ds["station_count"] = ((), 5)
    source = save(ds, tmp_path / "selected.nc")
    result = export_file(source, tmp_path / "out", variable_names=["elevation"])
    assert not result.errors
    assert len(result.files) == 1
    assert Path(result.files[0]).name.startswith("elevation-")
    assert any("station_count" in item for item in result.skipped)
    with pytest.raises(NetCDFError):
        export_file(source, tmp_path / "unknown", variable_names=["does_not_exist"])


def test_single_cell_axis_requires_consistent_cf_bounds(tmp_path):
    ds = geographic_dataset(np.array([[1, 2, 3]], dtype="float32"), lat=[10], lon=[100, 101, 102])
    without = save(ds, tmp_path / "singleton_without_bounds.nc")
    assert not variable(inspect_file(without)).spatial
    ds["lat_bounds"] = (("lat", "bounds"), [[9.5, 10.5]])
    ds.lat.attrs["bounds"] = "lat_bounds"
    source = save(ds, tmp_path / "singleton_bounds.nc")
    temp = variable(inspect_file(source))
    assert temp.spatial, temp.reason
    result = export_file(source, tmp_path / "out")
    assert not result.errors
    with rasterio.open(result.files[0]) as tif:
        assert tif.transform == from_origin(99.5, 10.5, 1, 1)
        np.testing.assert_array_equal(tif.read(1), [[1, 2, 3]])
