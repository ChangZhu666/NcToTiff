"""Regression checks through real Qt signals/event loops, never worker.run()."""
from __future__ import annotations

import gc
import json
import os
from pathlib import Path

import numpy as np
import pytest
import rasterio

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

from ncgeotiff.gui import MainWindow
from ncgeotiff.selftest import _close_test_window, _make_dataset, _wait_for_gui_task, run_gui_test


@pytest.fixture(scope="module")
def app():
    application = QApplication.instance() or QApplication([])
    application.setQuitOnLastWindowClosed(False)
    yield application


@pytest.fixture
def window(app, tmp_path):
    view = MainWindow()
    view.settings = QSettings(str(tmp_path / "settings.ini"), QSettings.Format.IniFormat)
    view.output_edit.clear()
    view.test_messages = []
    view._message = view.test_messages.append
    view.show()
    app.processEvents()
    yield view
    assert _close_test_window(view, app), "GUI worker did not stop at teardown"


def load_by_drop(window, source: Path):
    window.drop_zone.fileDropped.emit(str(source))
    # There is no local reference to InspectWorker after signal delivery.
    gc.collect()
    _wait_for_gui_task(window, timeout=15.0)


def assert_ready(window):
    assert not window._working
    assert window._thread is None
    assert window._worker is None
    assert window.run_button.isEnabled()
    assert not window._inspect_timer.isActive()


def assert_export(out_dir: Path):
    files = sorted(out_dir.glob("*.tif"))
    assert len(files) == 2
    for layer, path in enumerate(files):
        with rasterio.open(path) as tif:
            assert tif.crs.to_epsg() == 4326
            expected = np.arange(layer * 9, (layer + 1) * 9, dtype="float32").reshape(3, 3)
            if layer == 0:
                expected[1, 1] = np.nan
            np.testing.assert_allclose(tif.read(1, masked=True).filled(np.nan), expected, equal_nan=True)
    manifests = list(out_dir.glob("NCStudio-manifest-*.json"))
    assert len(manifests) == 1
    manifest = json.loads(manifests[0].read_text(encoding="utf-8"))
    assert len(manifest["outputs"]) == 2


def test_drop_analyse_and_button_export_survive_gc_and_repeat(window, tmp_path):
    for sequence in range(2):
        source = tmp_path / f"sample-{sequence}.nc"
        _make_dataset(source)
        load_by_drop(window, source)
        assert_ready(window)
        assert window.info is not None
        assert Path(window.info.path) == source
        assert window.info.dimensions == {"time": 2, "lat": 3, "lon": 3}
        assert window.info.layer_count == 2
        assert window.variable_table.rowCount() == 2
        assert "temperature" in window.space_text.toPlainText()
        assert "CF-1.8" in window.attrs_text.toPlainText()
        assert "元数据分析完成。" in window.log_text.toPlainText()
        output = tmp_path / f"out-{sequence}"
        window.output_edit.setText(str(output))
        window.run_button.click()
        gc.collect()
        _wait_for_gui_task(window, timeout=15.0)
        assert_ready(window)
        assert window.progress.value() == 100
        assert window.test_messages[-1] == "转换完成，共生成 2 个 GeoTIFF。"
        assert_export(output)


def test_analysis_failure_clears_old_metadata_and_allows_retry(window, tmp_path):
    source = tmp_path / "valid.nc"
    _make_dataset(source)
    load_by_drop(window, source)
    assert window.info is not None
    broken = tmp_path / "broken.nc"
    broken.write_bytes(b"this is not a NetCDF file")
    load_by_drop(window, broken)
    assert_ready(window)
    assert window.info is None
    assert window.analysis_path is None
    assert window.variable_table.rowCount() == 0
    assert window.test_messages
    assert "文件分析失败" in window.summary_label.text()
    load_by_drop(window, source)
    assert_ready(window)
    assert window.info is not None and window.info.layer_count == 2


def test_export_failure_can_retry_with_valid_output(window, tmp_path):
    source = tmp_path / "valid.nc"
    _make_dataset(source)
    load_by_drop(window, source)
    invalid_output = tmp_path / "not-a-directory"
    invalid_output.write_text("occupied", encoding="utf-8")
    window.output_edit.setText(str(invalid_output))
    window.run_button.click()
    _wait_for_gui_task(window, timeout=15.0)
    assert_ready(window)
    assert window.test_messages
    assert "错误：" in window.log_text.toPlainText()
    output = tmp_path / "retry"
    window.output_edit.setText(str(output))
    window.run_button.click()
    _wait_for_gui_task(window, timeout=15.0)
    assert_ready(window)
    assert_export(output)


def test_packaged_selftest_uses_gui_workflow(app):
    report = run_gui_test()
    assert report["ok"], report
    assert report["workflow"] == "gui-inspect-export"
    assert report["threads_cleaned_up"]
    assert any("开始分析" in line for line in report["gui_log"])
    assert any("处理完成" in line for line in report["gui_log"])
