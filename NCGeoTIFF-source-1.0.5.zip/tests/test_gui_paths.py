from pathlib import Path

from ncgeotiff.gui import _is_unc, _needs_local_cache


def test_unc_detection_only_matches_network_paths():
    assert _is_unc(Path(r"\\server\share\file.nc"))
    assert not _is_unc(Path(r"C:\data\file.nc"))
    assert not _is_unc(Path(r"\\?\UNC\server\share\file.nc"))


def test_local_cache_required_for_unc_or_non_ascii_paths():
    assert _needs_local_cache(Path(r"\\server\share\file.nc"))
    assert _needs_local_cache(Path(r"C:\Users\me\测试\file.nc"))
    assert not _needs_local_cache(Path(r"C:\data\file.nc"))
