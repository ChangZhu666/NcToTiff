# -*- mode: python ; coding: utf-8 -*-
"""Windows build: use build.ps1; NCSTUDIO_ONEFILE=1 selects a single EXE."""

import os
import shutil
import sys
from pathlib import Path

import netCDF4
import shiboken6
from PyInstaller.utils.hooks import (
    collect_data_files,
    collect_delvewheel_libs_directory,
    collect_dynamic_libs,
    collect_submodules,
    copy_metadata,
)

root = Path(SPECPATH)
onefile = os.environ.get("NCSTUDIO_ONEFILE", "0") == "1"
console = os.environ.get("NCSTUDIO_CONSOLE", "0") == "1"

datas = []
binaries = []
for package in ("rasterio", "pyproj", "netCDF4"):
    datas += collect_data_files(package)
    binaries += collect_dynamic_libs(package)
    # Windows wheels can keep vendored DLLs beside the Python package.
    datas, binaries = collect_delvewheel_libs_directory(
        package, datas=datas, binaries=binaries
    )

for distribution in ("xarray", "netCDF4", "rasterio", "pyproj", "cftime"):
    datas += copy_metadata(distribution)

shiboken_dir = Path(shiboken6.__file__).resolve().parent
for dll in shiboken_dir.glob("*.dll"):
    binaries.append((str(dll), "PySide6"))

vendor = root / "build" / "vendor-dlls"
vendor.mkdir(parents=True, exist_ok=True)
netcdf_dir = Path(netCDF4.__file__).resolve().parent.parent / "netcdf4.libs"
icuuc = next(netcdf_dir.glob("icuuc*.dll"), None)
icudt = next(netcdf_dir.glob("icudt*.dll"), None)
for source, name in ((icuuc, "icuuc.dll"), (icudt, "icudt78.dll")):
    if source is not None:
        target = vendor / name
        shutil.copy2(source, target)
        binaries.append((str(target), "PySide6"))
        binaries.append((str(source), "PySide6"))

python_home = Path(sys.base_prefix)
for name in ("python3.dll", f"python{sys.version_info.major}{sys.version_info.minor}.dll"):
    source = python_home / name
    if source.is_file():
        binaries.append((str(source), "PySide6"))

for search_root in os.environ.get("PATH", "").split(os.pathsep):
    folder = Path(search_root)
    try:
        if folder.is_dir():
            for dll in folder.glob("api-ms-win-*.dll"):
                binaries.append((str(dll), "PySide6"))
    except OSError:
        pass

assets = root / "ncgeotiff" / "assets"
if assets.is_dir():
    datas.append((str(assets), "ncgeotiff/assets"))
icon_path = assets / "app.ico"

# NetCDF4 is selected by name by xarray. Rasterio uses C-extension imports.
hiddenimports = ["xarray.backends.netCDF4_", "netCDF4.utils", "cftime"]
hiddenimports += collect_submodules(
    "rasterio", filter=lambda name: not name.startswith("rasterio.rio")
)

a = Analysis(
    [str(root / "launcher.py")],
    pathex=[str(root)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    runtime_hooks=[str(root / "hooks" / "runtime_paths.py")],
    excludes=[
        "tkinter", "PyQt5", "PyQt6", "PySide2",
        "matplotlib", "IPython", "jupyter", "pytest",
        "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets",
        "PySide6.QtQml", "PySide6.QtQuick", "PySide6.QtMultimedia",
    ],
    noarchive=False,
)
pyz = PYZ(a.pure)
options = dict(
    name="NCStudio",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=console,
    disable_windowed_traceback=False,
    icon=str(icon_path) if icon_path.is_file() else None,
)
if onefile:
    exe = EXE(pyz, a.scripts, a.binaries, a.datas, [], **options)
else:
    exe = EXE(pyz, a.scripts, [], exclude_binaries=True, **options)
    collect = COLLECT(
        exe, a.binaries, a.datas, strip=False, upx=False, name="NCStudio"
    )
