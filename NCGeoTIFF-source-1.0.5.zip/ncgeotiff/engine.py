"""CF-aware NetCDF inspection and bounded-memory GeoTIFF export.

Only proven, regular rectilinear grids are exported. A guessed projection or an
affine transform fitted to a curved grid would silently misplace scientific data.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product
import json
import math
import os
from pathlib import Path
import re
import threading
from typing import Callable, Iterator, Sequence
import uuid
import warnings

import netCDF4
import numpy as np
from pyproj import CRS, Transformer
import rasterio
from rasterio.transform import from_origin
from rasterio.windows import Window
import xarray as xr

from . import __version__
from .models import DatasetInfo, ExportResult, GridInfo, VariableInfo

_IO_LOCK = threading.RLock()  # netCDF/HDF5 libraries need not be thread safe.
_SUFFIXES = {".nc", ".nc4", ".cdf"}
_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
             *(f"LPT{i}" for i in range(1, 10))}


class NetCDFError(ValueError):
    """An actionable error suitable for presenting in the desktop UI."""


class UnsupportedGrid(NetCDFError):
    pass


class _Cancelled(Exception):
    pass


@dataclass
class _Grid:
    info: GridInfo
    crs: CRS
    reverse_x: bool
    reverse_y: bool


def _text(value) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, np.ndarray):
        return json.dumps(value.tolist(), ensure_ascii=False, default=str)
    return str(value)


def _attrs(attrs: dict) -> dict[str, str]:
    return {str(k): _text(v) for k, v in attrs.items()}


def _path(path: str | Path) -> Path:
    # Do not call resolve() here: on UNC/network shares it can block while
    # Windows tries to resolve every remote component. absolute() preserves the
    # usable path without chasing network metadata.
    source = Path(path).expanduser().absolute()
    if not source.is_file():
        raise NetCDFError(f"找不到文件：{source}")
    if source.suffix.lower() not in _SUFFIXES:
        raise NetCDFError("请选择 .nc、.nc4 或 .cdf 文件。")
    return source


@contextmanager
def _open(source: Path):
    notes: list[str] = []
    dataset = None
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        try:
            dataset = xr.open_dataset(source, engine="netcdf4", decode_coords="all",
                                      mask_and_scale=True, decode_timedelta=False,
                                      cache=False)
        except Exception as first_error:
            try:
                dataset = xr.open_dataset(source, engine="netcdf4", decode_coords="all",
                                          mask_and_scale=True, decode_times=False,
                                          decode_timedelta=False, cache=False)
                notes.append(f"时间解码失败，保留原始时间数值和单位：{first_error}")
            except Exception as error:
                raise NetCDFError(f"无法读取 NetCDF：{error}") from error
        notes.extend(str(w.message) for w in recorded)
    try:
        with netCDF4.Dataset(source, mode="r") as raw:
            if raw.groups:
                notes.append("当前只分析根组；以下 NetCDF 子组未转换：" + "、".join(raw.groups))
        yield dataset, notes
    finally:
        dataset.close()


def _kind(coord: xr.DataArray) -> str | None:
    name = str(coord.name).lower()
    std = str(coord.attrs.get("standard_name", "")).lower()
    units = str(coord.attrs.get("units", "")).lower().replace(" ", "_")
    if std in {"grid_longitude", "grid_latitude"}:
        return "rotated"
    if std == "longitude" or units in {"degree_east", "degrees_east", "degree_e", "degrees_e"}:
        return "lon"
    if std == "latitude" or units in {"degree_north", "degrees_north", "degree_n", "degrees_n"}:
        return "lat"
    if std in {"projection_x_coordinate", "projection_x_angular_coordinate"}:
        return "x"
    if std in {"projection_y_coordinate", "projection_y_angular_coordinate"}:
        return "y"
    if std:
        return None
    if name in {"longitude", "lon", "long", "nav_lon"}:
        return "lon"
    if name in {"latitude", "lat", "nav_lat"}:
        return "lat"
    axis = str(coord.attrs.get("axis", "")).upper()
    if axis == "X" or name in {"x", "easting"}:
        return "x"
    if axis == "Y" or name in {"y", "northing"}:
        return "y"
    return None


def _mapping(ds: xr.Dataset, da: xr.DataArray) -> tuple[CRS | None, dict, bool]:
    mapping = da.encoding.get("grid_mapping", da.attrs.get("grid_mapping", ""))
    attributes: dict = {}
    explicit = bool(mapping)
    if mapping:
        names = re.findall(r"([^\s:]+)\s*:", str(mapping)) if ":" in str(mapping) else str(mapping).split()
        if len(names) != 1:
            raise UnsupportedGrid("多个 CF grid_mapping 需要人工选择，暂不自动转换。")
        if names[0] not in ds.variables:
            raise UnsupportedGrid(f"缺少 grid_mapping 引用的坐标系变量：{names[0]}")
        attributes = dict(ds[names[0]].attrs)
    else:
        for candidate in (da.attrs, ds.attrs):
            if any(key in candidate for key in ("crs_wkt", "spatial_ref", "crs", "epsg_code")):
                attributes = dict(candidate)
                explicit = True
                break
        if not attributes:
            possible = [name for name in ("spatial_ref", "crs") if name in ds.variables
                        and any(k in ds[name].attrs for k in ("spatial_ref", "crs_wkt", "grid_mapping_name"))]
            if len(possible) == 1:
                attributes = dict(ds[possible[0]].attrs)
                explicit = True
    if not attributes:
        if explicit:
            raise UnsupportedGrid("grid_mapping 变量没有可解析的坐标系属性。")
        return None, {}, False
    if attributes.get("grid_mapping_name") == "rotated_latitude_longitude":
        raise UnsupportedGrid("旋转经纬网需要重投影，暂不直接写出 GeoTIFF。")
    errors = []
    for key in ("crs_wkt", "spatial_ref", "crs", "epsg_code"):
        if key in attributes:
            try:
                return CRS.from_user_input(attributes[key]), attributes, True
            except Exception as error:
                errors.append(str(error))
    if "grid_mapping_name" in attributes:
        try:
            return CRS.from_cf(attributes), attributes, True
        except Exception as error:
            errors.append(str(error))
    raise UnsupportedGrid("坐标系属性无法解析：" + ("；".join(errors) or "缺少 CF 投影参数 / WKT"))


def _coordinates(ds: xr.Dataset, da: xr.DataArray, crs: CRS | None):
    candidates = {str(name): coord for name, coord in da.coords.items()}
    for dim in da.dims:
        if dim in ds.variables:
            candidates[dim] = ds[dim]
    # Some older files omit coordinates="lon lat" but use unambiguous 1-D axes.
    for name, coord in ds.variables.items():
        if name not in candidates and len(coord.dims) == 1 and coord.dims[0] in da.dims:
            if _kind(ds[name]) in {"lon", "lat", "x", "y"}:
                candidates[str(name)] = ds[name]
    preferences = [("x", "y"), ("lon", "lat")] if crs and crs.is_projected else [("lon", "lat"), ("x", "y")]
    for xkind, ykind in preferences:
        xs = [c for c in candidates.values() if c.ndim == 1 and _kind(c) == xkind and c.dims[0] in da.dims]
        ys = [c for c in candidates.values() if c.ndim == 1 and _kind(c) == ykind and c.dims[0] in da.dims]
        if xs and ys:
            # Prefer explicit variable-attached coordinates over unrelated dataset axes.
            xs.sort(key=lambda c: (c.name not in da.coords, not bool(c.attrs.get("standard_name"))))
            ys.sort(key=lambda c: (c.name not in da.coords, not bool(c.attrs.get("standard_name"))))
            for values in (xs, ys):
                if len(values) > 1:
                    a, b = values[:2]
                    if (a.name in da.coords) == (b.name in da.coords) and bool(a.attrs.get("standard_name")) == bool(b.attrs.get("standard_name")):
                        raise UnsupportedGrid("存在多个可能的空间坐标，无法唯一确定网格。")
            if xs[0].dims[0] == ys[0].dims[0]:
                raise UnsupportedGrid("经纬度共享一个维度（站点 / 轨迹），不是二维规则网格。")
            return xs[0], ys[0], xkind == "lon"
    if any(_kind(c) == "rotated" for c in candidates.values()):
        raise UnsupportedGrid("旋转经纬网需要重投影，暂不直接转换。")
    if any(c.ndim >= 2 and _kind(c) in {"lon", "lat"} for c in candidates.values()):
        raise UnsupportedGrid("二维经纬度 / 曲线网格需要重采样，暂不直接转换。")
    raise UnsupportedGrid("没有识别到两条独立的一维空间坐标。")


def _unit_factor(coord: xr.DataArray, crs: CRS, geographic: bool, notes: list[str]) -> float:
    units = str(coord.attrs.get("units", "")).strip().lower().replace(" ", "_")
    if geographic:
        if not units or units.startswith("degree") or units in {"deg", "°"}:
            return 1.0
        if units in {"radian", "radians", "rad"}:
            return 180 / math.pi
        raise UnsupportedGrid(f"经纬度坐标 {coord.name} 的单位无法识别：{units}")
    if not crs.is_projected:
        raise UnsupportedGrid("X/Y 坐标缺少明确的投影坐标系，不能假定为经纬度。")
    factors = {"m": 1, "meter": 1, "meters": 1, "metre": 1, "metres": 1,
               "km": 1000, "kilometer": 1000, "kilometers": 1000, "kilometre": 1000,
               "kilometres": 1000, "cm": .01, "mm": .001,
               "ft": .3048, "foot": .3048, "feet": .3048,
               "us_survey_foot": 1200 / 3937, "us_survey_feet": 1200 / 3937}
    axis = "east" if _kind(coord) == "x" else "north"
    axes = [a for a in crs.axis_info if a.direction in ({"east", "west"} if axis == "east" else {"north", "south"})]
    native_factor = (axes[0] if axes else crs.axis_info[0]).unit_conversion_factor
    if not units:
        notes.append(f"{coord.name} 没有单位；按 CRS 的坐标单位解释。")
        return 1.0
    if units not in factors:
        raise UnsupportedGrid(f"投影坐标 {coord.name} 的单位暂不支持：{units}（角度扫描坐标需要专用转换）")
    factor = factors[units] / native_factor
    if not math.isclose(factor, 1):
        notes.append(f"{coord.name} 坐标由 {units} 换算为 CRS 单位，系数 {factor:g}。")
    return factor


def _axis(ds: xr.Dataset, coord: xr.DataArray, factor: float, longitude: bool, notes: list[str]):
    try:
        values = np.asarray(coord.values, dtype="float64") * factor
    except (ValueError, TypeError) as error:
        raise UnsupportedGrid(f"{coord.name} 不是数值坐标。") from error
    if not values.size or not np.isfinite(values).all():
        raise UnsupportedGrid(f"{coord.name} 为空或含有缺失 / 非有限坐标。")
    bounds_name = coord.attrs.get("bounds", coord.encoding.get("bounds"))
    bounds = None
    if bounds_name and bounds_name in ds:
        b = ds[bounds_name]
        other = [d for d in b.dims if d != coord.dims[0]]
        if len(other) == 1 and b.sizes[other[0]] == 2 and coord.dims[0] in b.dims:
            bounds = np.asarray(b.transpose(coord.dims[0], other[0]).values, dtype=float) * factor
        else:
            raise UnsupportedGrid(f"{coord.name} 的 bounds 不是 (坐标, 2) 形式。")
    if len(values) == 1:
        if bounds is None or not np.isfinite(bounds).all():
            raise UnsupportedGrid(f"{coord.name} 只有一个像元且没有有效 bounds，无法推断分辨率。")
        spacing = abs(float(bounds[0, 1] - bounds[0, 0]))
        if not spacing or not np.isclose(values[0], bounds.mean(), atol=spacing * 1e-5, rtol=0):
            raise UnsupportedGrid(f"{coord.name} 的单像元 bounds 与中心坐标不一致。")
        return values, spacing
    diffs = np.diff(values)
    if longitude and np.any(np.abs(diffs) > 180) and not (np.all(diffs > 0) or np.all(diffs < 0)):
        values = np.rad2deg(np.unwrap(np.deg2rad(values)))
        diffs = np.diff(values)
        notes.append(f"{coord.name} 跨越日期变更线，已展开为连续经度；没有重采样。")
        if bounds is not None:
            bounds = values[:, None] + (bounds - values[:, None] + 180) % 360 - 180
    if not (np.all(diffs > 0) or np.all(diffs < 0)):
        raise UnsupportedGrid(f"{coord.name} 含重复值或不是严格单调坐标。")
    step = (values[-1] - values[0]) / (len(values) - 1)
    precision = np.finfo(coord.dtype).eps if np.issubdtype(coord.dtype, np.floating) else np.finfo(float).eps
    tolerance = max(abs(step) * 1e-5, abs(values).max() * precision * 2, 1e-10)
    if not np.allclose(values, values[0] + np.arange(len(values)) * step, rtol=0, atol=tolerance):
        raise UnsupportedGrid(f"{coord.name} 不是等间距坐标；需要先重采样。")
    spacing = abs(float(step))
    if bounds is not None:
        expected = np.column_stack((values - spacing / 2, values + spacing / 2))
        if not np.allclose(np.sort(bounds, axis=1), expected, rtol=0, atol=tolerance):
            raise UnsupportedGrid(f"{coord.name} 的 bounds 与规则像元中心不一致，需先重采样。")
    return values, spacing


def _grid(ds: xr.Dataset, da: xr.DataArray) -> _Grid:
    if da.ndim < 2:
        raise UnsupportedGrid("不是二维或多维空间变量。")
    if da.dtype.kind not in "biuf":
        raise UnsupportedGrid("仅支持实数数值变量，跳过字符、日期、复数或对象类型。")
    if any(size == 0 for size in da.shape):
        raise UnsupportedGrid("变量包含长度为 0 的维度。")
    crs, _, explicit = _mapping(ds, da)
    xcoord, ycoord, geographic = _coordinates(ds, da, crs)
    notes = []
    if crs is None:
        if not geographic:
            raise UnsupportedGrid("投影 X/Y 坐标缺少 CRS / CF grid_mapping，不能可靠定位。")
        crs = CRS.from_epsg(4326)
        notes.append("识别到经纬度但未声明大地基准；按 WGS 84 / EPSG:4326 输出。")
    if geographic and not crs.is_geographic:
        raise UnsupportedGrid("经纬度坐标与声明的投影 CRS 不一致。")
    if geographic and crs.is_derived:
        raise UnsupportedGrid("派生 / 旋转地理坐标系需要专用重投影。")
    fx = _unit_factor(xcoord, crs, geographic, notes)
    fy = _unit_factor(ycoord, crs, geographic, notes)
    x, dx = _axis(ds, xcoord, fx, geographic, notes)
    y, dy = _axis(ds, ycoord, fy, False, notes)
    if geographic:
        if y.min() < -90 - 1e-7 or y.max() > 90 + 1e-7:
            raise UnsupportedGrid("纬度中心超出 -90° 至 90°，请检查坐标单位。")
        if x.max() - x.min() > 360 + 1e-6:
            raise UnsupportedGrid("经度跨度超过 360°，请检查坐标。")
        if x.min() < -180 or x.max() > 180:
            notes.append("保留原始连续经度（可能为 0–360°）；未强制切分为 -180–180°。")
    bounds = (float(x.min() - dx / 2), float(y.min() - dy / 2),
              float(x.max() + dx / 2), float(y.max() + dy / 2))
    lonlat = None
    if geographic:
        lonlat = bounds
        if bounds[1] < -90 or bounds[3] > 90:
            notes.append("像元边缘超过极点；保留中心与分辨率，不裁剪像元。")
    else:
        try:
            transformed = Transformer.from_crs(crs, "EPSG:4326", always_xy=True).transform_bounds(*bounds, densify_pts=21)
            if all(math.isfinite(v) for v in transformed):
                lonlat = tuple(float(v) for v in transformed)
            else:
                notes.append("无法将全部网格边缘转换为经纬度；输出仍使用原始 CRS。")
        except Exception as error:
            notes.append(f"经纬度范围估算失败：{error}")
    identity = crs.to_authority()
    crs_label = f"{identity[0]}:{identity[1]}" if identity else crs.to_wkt()
    info = GridInfo(crs_label, str(xcoord.name), str(ycoord.name), xcoord.dims[0], ycoord.dims[0],
                    len(x), len(y), bounds, (dx, dy), lonlat, notes)
    return _Grid(info, crs, len(x) > 1 and x[0] > x[-1], len(y) > 1 and y[0] < y[-1])


def _is_time(coord: xr.DataArray) -> bool:
    return (str(coord.name).lower() in {"time", "valid_time", "date", "datetime"}
            or coord.attrs.get("standard_name") == "time"
            or str(coord.attrs.get("axis", "")).upper() == "T"
            or " since " in str(coord.attrs.get("units", coord.encoding.get("units", "")))
            or coord.dtype.kind == "M")


def _value(value) -> str:
    if isinstance(value, np.datetime64):
        return np.datetime_as_string(value, unit="auto")
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def _time_summary(coords) -> str:
    parts = []
    for name, coord in coords.items():
        if not _is_time(coord) or not coord.size:
            continue
        if coord.ndim > 1:
            parts.append(f"{name}：{coord.shape} 多维时间坐标")
            continue
        first = _value(coord.isel({coord.dims[0]: 0}).values[()] if coord.ndim else coord.values[()])
        last = _value(coord.isel({coord.dims[0]: -1}).values[()] if coord.ndim else coord.values[()])
        calendar = coord.encoding.get("calendar", coord.attrs.get("calendar", "standard"))
        units = coord.attrs.get("units", "")
        parts.append(f"{name}：{first} → {last} · {coord.size} 层 · {calendar}" + (f" · {units}" if units else ""))
    return "\n".join(parts) or "无时间坐标（输出使用 static）"


def _inspect(ds: xr.Dataset, source: Path, notes: list[str]) -> tuple[DatasetInfo, dict[str, _Grid]]:
    infos = []
    grids = {}
    for name, da in ds.data_vars.items():
        info = VariableInfo(str(name), tuple(da.dims), tuple(da.shape), str(da.dtype),
                            str(da.attrs.get("units", "—")), False,
                            attributes=_attrs(da.attrs), time_summary=_time_summary(da.coords))
        for key in ("_FillValue", "missing_value", "scale_factor", "add_offset", "grid_mapping"):
            if key in da.encoding:
                info.attributes[key] = _text(da.encoding[key])
        try:
            grid = _grid(ds, da)
            info.spatial, info.grid = True, grid.info
            info.layer_count = math.prod(da.sizes[d] for d in da.dims if d not in {grid.info.x_dim, grid.info.y_dim})
            info.reason = "可转换" if not grid.info.warnings else "可转换（请查看空间提示）"
            grids[str(name)] = grid
        except UnsupportedGrid as error:
            info.reason = str(error)
        except Exception as error:
            info.reason = f"分析该变量失败：{error}"
        infos.append(info)
    coordinates = {}
    for name, coord in ds.coords.items():
        item = {"dimensions": list(coord.dims), "shape": list(coord.shape), "dtype": str(coord.dtype),
                "attributes": _attrs(coord.attrs)}
        # Summaries of coordinate vectors do not force the field variables into memory.
        if coord.ndim <= 1 and coord.size:
            item["first"] = _value(coord.isel({coord.dims[0]: 0}).values[()] if coord.ndim else coord.values[()])
            item["last"] = _value(coord.isel({coord.dims[0]: -1}).values[()] if coord.ndim else coord.values[()])
        coordinates[str(name)] = item
    return DatasetInfo(str(source), source.stat().st_size, dict(ds.sizes), _attrs(ds.attrs), infos,
                       coordinates, list(dict.fromkeys(notes)), _time_summary(ds.coords)), grids


def inspect_file(path: str | Path) -> DatasetInfo:
    """Read metadata, coordinate vectors and bounds, not complete field arrays."""
    source = _path(path)
    with _IO_LOCK, _open(source) as (ds, notes):
        return _inspect(ds, source, notes)[0]


def _safe(value: str, limit: int = 64) -> str:
    clean = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(value))
    clean = re.sub(r"\s+", "_", clean).strip(" ._") or "unnamed"
    if clean.split(".")[0].upper() in _RESERVED:
        clean = "_" + clean
    if len(clean) > limit:
        clean = clean[:limit - 11] + "_" + sha256(clean.encode()).hexdigest()[:10]
    return clean


def _layer_label(da: xr.DataArray, indices: dict[str, int], grid: GridInfo):
    times, extra, labels = [], [], {}
    used_dims = set()
    for name, coord in da.coords.items():
        if _is_time(coord) and all(d in indices for d in coord.dims):
            value = _value(coord.isel({d: indices[d] for d in coord.dims}).values[()])
            labels[str(name)] = value
            token = re.sub(r"[-:]", "", value).replace(" ", "T")
            if coord.dtype.kind in "iuf":
                token = f"{name}_{value}"
            times.append(_safe(token, 48))
            used_dims.update(coord.dims)
    for dim, index in indices.items():
        value = _value(da[dim].isel({dim: index}).values[()]) if dim in da.coords else str(index)
        labels[dim] = value
        if dim not in used_dims:
            extra.append(_safe(f"{dim}_{value}", 32))
    variable = _safe(str(da.name) + ("_" + "_".join(extra) if extra else ""), 70)
    time = _safe("_".join(times) if times else "static", 64)
    west, south, east, north = grid.bounds
    extent = f"x{west:.6g}_{east:.6g}_y{south:.6g}_{north:.6g}"
    return f"{variable}-{time}-{extent}", labels


def _publish(temp: Path, folder: Path, stem: str, extension: str) -> Path:
    # Windows rename is atomic and never replaces an existing destination.
    # POSIX hard-link creation gives the same exclusive publication behavior.
    for index in range(1, 100000):
        suffix = "" if index == 1 else f"__{index}"
        target = folder / f"{stem}{suffix}{extension}"
        try:
            if os.name == "nt":
                temp.rename(target)
            else:
                os.link(temp, target)
                temp.unlink()
            return target
        except FileExistsError:
            continue
    raise NetCDFError("同名文件过多，请选择新的输出目录。")


def _write_layer(da: xr.DataArray, indices: dict[str, int], grid: _Grid, target: Path,
                 cancelled: Callable[[], bool], report: Callable[[float], None], source: Path, labels: dict):
    g = grid.info
    layer = da.isel(indices).transpose(g.y_dim, g.x_dim)
    dtype = np.dtype(layer.dtype)
    if dtype.kind == "b":
        dtype = np.dtype("uint8")
    elif dtype == np.dtype("int8"):
        dtype = np.dtype("int16")
    elif dtype.kind == "f" and dtype.itemsize < 4:
        dtype = np.dtype("float32")
    if not rasterio.dtypes.check_dtype(dtype.name):
        raise NetCDFError(f"GeoTIFF 不支持数据类型：{dtype}")
    nodata = float("nan") if dtype.kind == "f" else None
    profile = dict(driver="GTiff", width=g.width, height=g.height, count=1, dtype=dtype.name,
                   crs=grid.crs.to_wkt(), transform=from_origin(g.bounds[0], g.bounds[3], *g.resolution),
                   nodata=nodata, compress="deflate", tiled=True, blockxsize=256, blockysize=256,
                   BIGTIFF="IF_SAFER")
    with rasterio.open(target, "w", **profile) as dst:
        # Subdivide both dimensions; even an extremely wide field stays bounded.
        chunk = 512
        blocks = math.ceil(g.height / chunk) * math.ceil(g.width / chunk)
        count = 0
        for row in range(0, g.height, chunk):
            height = min(chunk, g.height - row)
            sy = slice(g.height - row - height, g.height - row) if grid.reverse_y else slice(row, row + height)
            for col in range(0, g.width, chunk):
                if cancelled():
                    raise _Cancelled()
                width = min(chunk, g.width - col)
                sx = slice(g.width - col - width, g.width - col) if grid.reverse_x else slice(col, col + width)
                block = np.asarray(layer.isel({g.y_dim: sy, g.x_dim: sx}).values, dtype=dtype)
                if grid.reverse_y:
                    block = block[::-1, :]
                if grid.reverse_x:
                    block = block[:, ::-1]
                dst.write(np.ascontiguousarray(block), 1, window=Window(col, row, width, height))
                count += 1
                report(count / blocks)
        dst.set_band_description(1, str(da.attrs.get("long_name", da.name)))
        if da.attrs.get("units"):
            dst.set_band_unit(1, str(da.attrs["units"]))
        dst.update_tags(AREA_OR_POINT="Area", source_file=str(source), variable=str(da.name),
                        units=str(da.attrs.get("units", "")), software=f"NC Studio {__version__}",
                        slice=json.dumps(labels, ensure_ascii=False),
                        source_attributes=json.dumps(_attrs(da.attrs), ensure_ascii=False),
                        conversion_notes=" | ".join(g.warnings))
    if cancelled():
        raise _Cancelled()


def export_file(path: str | Path, output_dir: str | Path, *,
                variable_names: Sequence[str] | None = None,
                progress: Callable[[int, int, str], None] | None = None,
                log: Callable[[str], None] | None = None,
                cancel: Callable[[], bool] | None = None) -> ExportResult:
    """Export each non-spatial slice as a one-band TIFF and write a JSON manifest.

    Progress counts completed layers; the message also reports within-layer work.
    Completed TIFFs are retained on cancellation. Existing files are never replaced.
    """
    source = _path(path)
    folder = Path(output_dir).expanduser().resolve()
    if os.name == "nt" and len(str(folder)) > 180:
        raise NetCDFError("输出目录路径过长，请选择较短的路径（建议 C:\\NCOutput）。")
    try:
        folder.mkdir(parents=True, exist_ok=True)
    except OSError as error:
        raise NetCDFError(f"无法创建输出目录：{error}") from error
    progress = progress or (lambda *_: None)
    log = log or (lambda _: None)
    cancelled = cancel or (lambda: False)
    result = ExportResult()
    records = []
    started = datetime.now(timezone.utc).isoformat()
    with _IO_LOCK, _open(source) as (ds, notes):
        info, grids = _inspect(ds, source, notes)
        chosen = set(variable_names) if variable_names is not None else set(grids)
        unknown = chosen - {v.name for v in info.variables}
        if unknown:
            raise NetCDFError("文件没有这些变量：" + "、".join(sorted(unknown)))
        if variable_names is not None and not chosen:
            raise NetCDFError("请至少选择一个可转换变量。")
        for warning in info.warnings:
            log("提示：" + warning)
        for item in info.variables:
            if not item.spatial:
                message = f"跳过 {item.name}：{item.reason}"
                result.skipped.append(message)
                log(message)
            elif item.name in chosen:
                for warning in item.grid.warnings:
                    log(f"{item.name}：{warning}")
        jobs = [v for v in info.variables if v.spatial and v.name in chosen]
        total = sum(v.layer_count for v in jobs)
        if total == 0:
            raise NetCDFError("没有可转换的规则空间变量。请查看变量清单中的跳过原因。")
        progress(0, total, f"准备转换 {len(jobs)} 个变量，共 {total} 层")
        done = 0
        for item in jobs:
            if cancelled():
                result.cancelled = True
                break
            da, grid = ds[item.name], grids[item.name]
            dims = [d for d in da.dims if d not in {grid.info.x_dim, grid.info.y_dim}]
            for combination in product(*(range(da.sizes[d]) for d in dims)):
                if cancelled():
                    result.cancelled = True
                    break
                indices = dict(zip(dims, combination))
                stem, labels = _layer_label(da, indices, grid.info)
                max_stem = min(185, 235 - len(str(folder))) if os.name == "nt" else 185
                stem = _safe(stem, max(32, max_stem))
                temp = folder / f".ncstudio-{uuid.uuid4().hex}.partial.tif"
                last_percent = -1
                def report(fraction):
                    nonlocal last_percent
                    percent = int(fraction * 100)
                    if percent != last_percent:
                        progress(done, total, f"{item.name} · 当前层 {percent}% · 已完成 {done}/{total}")
                        last_percent = percent
                try:
                    log(f"正在写出 {stem}.tif")
                    _write_layer(da, indices, grid, temp, cancelled, report, source, labels)
                    target = _publish(temp, folder, stem, ".tif")
                    result.files.append(str(target))
                    records.append({"file": target.name, "variable": item.name, "indices": indices,
                                    "coordinates": labels, "grid": asdict(grid.info)})
                except _Cancelled:
                    result.cancelled = True
                    break
                except Exception as error:
                    message = f"{item.name} {labels}：{error}"
                    result.errors.append(message)
                    log("错误：" + message)
                finally:
                    if temp.exists():
                        try:
                            temp.unlink()
                        except OSError as error:
                            result.errors.append(f"未完成文件清理失败 {temp.name}：{error}")
                done += 1
                progress(done, total, f"已处理 {done}/{total} 层 · 成功 {len(result.files)} · 失败 {len(result.errors)}")
            if result.cancelled:
                break
        manifest = {"software": f"NC Studio {__version__}", "started_utc": started,
                    "finished_utc": datetime.now(timezone.utc).isoformat(),
                    "source": info.to_dict(), "selected_variables": sorted(chosen),
                    "planned_layers": total, "completed_layers": len(result.files),
                    "cancelled": result.cancelled, "errors": result.errors,
                    "skipped": result.skipped, "outputs": records}
        temp_manifest = folder / f".ncstudio-{uuid.uuid4().hex}.partial.json"
        try:
            temp_manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
            result.manifest_path = str(_publish(temp_manifest, folder,
                "NCStudio-manifest-" + datetime.now().strftime("%Y%m%d-%H%M%S"), ".json"))
            log(f"转换清单：{result.manifest_path}")
        except OSError as error:
            result.errors.append(f"无法写入转换清单：{error}")
            log(result.errors[-1])
        finally:
            if temp_manifest.exists():
                temp_manifest.unlink(missing_ok=True)
        log(("已取消。" if result.cancelled else "处理完成。") + f" 成功 {len(result.files)} 个文件，错误 {len(result.errors)} 条。")
    return result
