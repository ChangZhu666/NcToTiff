"""Small end-to-end checks used by the packaged application."""
from __future__ import annotations

from dataclasses import asdict
import gc
import os
from pathlib import Path
import platform
import sys
import tempfile
import time
import traceback

import numpy as np
import rasterio
from pyproj import CRS
import xarray as xr

from . import __version__

# Retain a test window if a native I/O call ignores cancellation. Its owning
# process can then be stopped by the outer smoke-test deadline without Python
# first deleting a running QThread. Never terminate a thread inside HDF5.
_UNFINISHED_WINDOWS: list = []


def _make_dataset(path: Path) -> None:
    lat = np.array([30.0, 20.0, 10.0], dtype="float64")
    lon = np.array([100.0, 110.0, 120.0], dtype="float64")
    time = np.array(["2026-01-01", "2026-01-02"], dtype="datetime64[D]")
    values = np.arange(time.size * lat.size * lon.size, dtype="float32").reshape(2, 3, 3)
    values[0, 1, 1] = np.nan
    ds = xr.Dataset(
        {
            "temperature": (
                ("time", "lat", "lon"),
                values,
                {"units": "K", "long_name": "Air temperature"},
            ),
            "station_count": (("time",), np.array([4, 5], dtype="int16")),
        },
        coords={
            "time": ("time", time, {"standard_name": "time"}),
            "lat": ("lat", lat, {"standard_name": "latitude", "units": "degrees_north", "axis": "Y"}),
            "lon": ("lon", lon, {"standard_name": "longitude", "units": "degrees_east", "axis": "X"}),
        },
        attrs={"Conventions": "CF-1.8", "title": "NC Studio self test"},
    )
    ds.to_netcdf(path, engine="netcdf4")


def _wait_for_gui_task(window, timeout: float = 30.0) -> None:
    """Run a real Qt event loop until the UI has handled thread completion."""
    from PySide6.QtCore import QEventLoop, QTimer

    loop = QEventLoop()
    poll = QTimer()
    poll.setInterval(10)
    deadline = QTimer()
    deadline.setSingleShot(True)
    expired = False

    def check() -> None:
        if not window._working and window._thread is None:
            loop.quit()

    def expire() -> None:
        nonlocal expired
        expired = True
        loop.quit()

    poll.timeout.connect(check)
    deadline.timeout.connect(expire)
    # Collect after load_file/start_export has returned. Keeping a worker only
    # in either method's local variable must fail this test, as in the GUI.
    gc.collect()
    poll.start()
    deadline.start(max(1, int(timeout * 1000)))
    try:
        if window._working or window._thread is not None:
            loop.exec()
    finally:
        poll.stop()
        deadline.stop()
    if expired:
        raise TimeoutError(
            f"GUI task did not complete within {timeout:g}s.\n"
            + window.log_text.toPlainText()
        )


def _close_test_window(window, app) -> bool:
    """Drain idle/cancelled workers before letting the test window go away."""
    if window._thread is not None:
        window.close()  # Uses the application's deferred-close/cancel path.
        window._thread.requestInterruption()
        window._thread.quit()
        try:
            _wait_for_gui_task(window, timeout=5.0)
        except TimeoutError:
            _UNFINISHED_WINDOWS.append(window)
            return False
    window.close()
    app.processEvents()
    return True


def run_gui_test(path: str | None = None) -> dict:
    """Exercise the actual drop/load and button/export workflow.

    Supplying a path analyses that file only. With no path, generate a tiny CF
    fixture and verify both exported layers. This works from a frozen EXE too.
    """
    started = time.monotonic()
    report = {
        "ok": False,
        "version": __version__,
        "python": sys.version,
        "platform": platform.platform(),
        "frozen": bool(getattr(sys, "frozen", False)),
        "checks": [],
        "errors": [],
        "workflow": "gui-inspect" if path else "gui-inspect-export",
        "gui_log": [],
        "messages": [],
    }
    window = None
    app = None
    previous_quit = None
    try:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtCore import QSettings
        from PySide6.QtWidgets import QApplication
        from .gui import MainWindow

        app = QApplication.instance() or QApplication([])
        previous_quit = app.quitOnLastWindowClosed()
        app.setQuitOnLastWindowClosed(False)
        with tempfile.TemporaryDirectory(prefix="ncstudio-selftest-") as tmp:
            root = Path(tmp)
            nc_path = Path(path).expanduser().absolute() if path else root / "sample.nc"
            out_dir = root / "out"
            if path is None:
                _make_dataset(nc_path)
            window = MainWindow()
            # Isolate the saved output preference from the user's real app.
            window.settings = QSettings(str(root / "settings.ini"), QSettings.Format.IniFormat)
            window.output_edit.setText(str(out_dir))
            # Capture dialogs while preserving the real completion callbacks.
            window._message = report["messages"].append
            window.show()
            app.processEvents()
            report["checks"].append({"gui": "real Qt event loop and background workers"})
            analysis_started = time.monotonic()
            window.drop_zone.fileDropped.emit(str(nc_path))
            try:
                _wait_for_gui_task(window, timeout=45.0)
                report["analysis_seconds"] = round(time.monotonic() - analysis_started, 3)
                assert window.info is not None, window.log_text.toPlainText()
                assert window.run_button.isEnabled()
                assert window.variable_table.rowCount() == len(window.info.variables)
                assert "元数据分析完成。" in window.log_text.toPlainText()
                info = window.info
                spatial = [item.name for item in info.variables if item.spatial]
                report["metadata"] = asdict(info)
                report["analysis_path"] = window.analysis_path
                report["checks"].append({"inspect": asdict(info), "spatial": spatial})
                if path is None:
                    assert spatial == ["temperature"], spatial
                    assert info.layer_count == 2
                    export_started = time.monotonic()
                    window.run_button.click()
                    _wait_for_gui_task(window, timeout=45.0)
                    report["export_seconds"] = round(time.monotonic() - export_started, 3)
                    files = sorted(out_dir.glob("*.tif"))
                    manifests = list(out_dir.glob("NCStudio-manifest-*.json"))
                    assert len(files) == 2, window.log_text.toPlainText()
                    assert len(manifests) == 1
                    assert window.progress.value() == 100
                    assert report["messages"] == ["转换完成，共生成 2 个 GeoTIFF。"], report["messages"]
                    report["checks"].append({"exported": [str(p) for p in files], "manifest": str(manifests[0])})
                    for layer, file in enumerate(files):
                        with rasterio.open(file) as tif:
                            assert tif.crs == CRS.from_epsg(4326)
                            assert tif.width == 3 and tif.height == 3 and tif.count == 1
                            expected = np.arange(layer * 9, (layer + 1) * 9, dtype="float32").reshape(3, 3)
                            if layer == 0:
                                expected[1, 1] = np.nan
                            np.testing.assert_allclose(tif.read(1, masked=True).filled(np.nan), expected, equal_nan=True)
                    report["checks"].append({"geotiff": "both layers, pixel values, nodata and CRS verified"})
            finally:
                report["gui_log"] = window.log_text.toPlainText().splitlines()
                report["threads_cleaned_up"] = _close_test_window(window, app)
                if not report["threads_cleaned_up"]:
                    raise RuntimeError("后台 I/O 尚未退出，需由外层测试进程超时终止。")

        report["ok"] = True
    except Exception as exc:  # pragma: no cover - exercised by frozen smoke failures.
        report["errors"].append(str(exc))
        report["traceback"] = traceback.format_exc()
    finally:
        if app is not None and previous_quit is not None:
            app.setQuitOnLastWindowClosed(previous_quit)
        report["elapsed_seconds"] = round(time.monotonic() - started, 3)
    return report


def run_self_test() -> dict:
    """The default packaged smoke test includes the complete GUI workflow."""
    return run_gui_test()
