"""PySide6 desktop interface for NC Studio."""
from __future__ import annotations

from dataclasses import asdict
from hashlib import sha256
import json
import os
from pathlib import Path
import threading
import time
from typing import Callable

from PySide6.QtCore import QEasingCurve, QEvent, QObject, QPoint, QPropertyAnimation, QRectF, QSettings, QSize, Qt, QThread, QTimer, Signal, Slot
from PySide6.QtGui import QColor, QDragEnterEvent, QDragLeaveEvent, QDropEvent, QFont, QPainter, QPen
from PySide6.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QProgressBar,
    QSizePolicy,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from . import __version__
from .engine import NetCDFError, export_file, inspect_file
from .models import DatasetInfo, ExportResult


class DropZone(QFrame):
    fileDropped = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self.setAcceptDrops(True)
        self._hover = False
        self._selected = False
        self._subtitle = "将 .nc / .nc4 / .cdf 文件拖到这里"
        self.setMinimumHeight(154)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set_selected(self, selected: bool, subtitle: str | None = None) -> None:
        self._selected = selected
        if subtitle is not None:
            self._subtitle = subtitle
        self.update()

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if _first_nc_path(event.mimeData()) is not None:
            self._hover = True
            event.acceptProposedAction()
            self.update()
        else:
            event.ignore()

    def dragLeaveEvent(self, event: QDragLeaveEvent) -> None:
        self._hover = False
        self.update()
        super().dragLeaveEvent(event)

    def dropEvent(self, event: QDropEvent) -> None:
        self._hover = False
        path = _first_nc_path(event.mimeData())
        if path:
            self.fileDropped.emit(path)
            event.acceptProposedAction()
        self.update()

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            path, _ = QFileDialog.getOpenFileName(self, "选择 NetCDF 文件", "", "NetCDF (*.nc *.nc4 *.cdf)")
            if path:
                self.fileDropped.emit(path)
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(2, 2, -2, -2)
        if self._hover:
            border = QColor("#007aff")
            fill = QColor("#eef6ff")
        elif self._selected:
            border = QColor("#34c759")
            fill = QColor("#f2fbf5")
        else:
            border = QColor("#d2d2d7")
            fill = QColor("#ffffff")
        pen = QPen(border, 2.0 if self._hover or self._selected else 1.3)
        pen.setStyle(Qt.PenStyle.SolidLine if self._selected else Qt.PenStyle.DashLine)
        painter.setPen(pen)
        painter.setBrush(fill)
        painter.drawRoundedRect(rect, 18, 18)
        painter.setPen(QColor("#1d1d1f"))
        font = QFont()
        font.setPointSize(18)
        font.setWeight(QFont.Weight.DemiBold)
        painter.setFont(font)
        painter.drawText(rect.adjusted(0, 34, 0, 0), Qt.AlignmentFlag.AlignHCenter, "拖入 NetCDF")
        painter.setPen(QColor("#6e6e73"))
        font.setPointSize(10)
        font.setWeight(QFont.Weight.Normal)
        painter.setFont(font)
        painter.drawText(rect.adjusted(20, 82, -20, 0), Qt.AlignmentFlag.AlignHCenter, self._subtitle)


def _first_nc_path(mime) -> str | None:
    for url in mime.urls():
        path = Path(url.toLocalFile())
        if path.suffix.lower() in {".nc", ".nc4", ".cdf"}:
            return str(path)
    return None


class InspectWorker(QObject):
    finished = Signal(object)
    failed = Signal(str)
    status = Signal(str)

    def __init__(self, path: str) -> None:
        super().__init__()
        self.path = path

    @Slot()
    def run(self) -> None:
        try:
            self.status.emit(f"NC Studio {__version__} 开始分析。")
            self.status.emit(f"原始文件：{self.path}")
            analysis_path = _local_analysis_path(Path(self.path), self.status.emit)
            if str(analysis_path) != self.path:
                self.status.emit(f"安全读取路径：{analysis_path}")
            self.status.emit("正在读取 NetCDF 文件头...")
            info = inspect_file(analysis_path)
            if str(analysis_path) != self.path:
                info.path = self.path
                info.warnings.append(f"原始路径已缓存到本地安全路径用于读取：{analysis_path}")
            self.finished.emit((info, str(analysis_path)))
        except Exception as exc:
            self.failed.emit(str(exc))


class ExportWorker(QObject):
    progress = Signal(int, int, str)
    log = Signal(str)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, path: str, output: str, variables: list[str] | None, cancel_event: threading.Event) -> None:
        super().__init__()
        self.path = path
        self.output = output
        self.variables = variables
        self.cancel_event = cancel_event

    @Slot()
    def run(self) -> None:
        try:
            result = export_file(
                self.path,
                self.output,
                variable_names=self.variables,
                progress=lambda done, total, message: self.progress.emit(done, total, message),
                log=self.log.emit,
                cancel=self.cancel_event.is_set,
            )
            self.finished.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self, initial_path: str | None = None) -> None:
        super().__init__()
        self.setWindowTitle(f"NC Studio {__version__}")
        self.resize(1120, 840)
        self.settings = QSettings("NCStudio", "NCGeoTIFF")
        self.info: DatasetInfo | None = None
        self.source_path: str | None = None
        self.analysis_path: str | None = None
        self._thread: QThread | None = None
        # Qt signal connections do not own a Python-created, parentless worker.
        # Keep it alive until the thread has stopped, for inspect AND export.
        self._worker: QObject | None = None
        self._on_worker_success: Callable[[object], None] | None = None
        self._worker_result: object = None
        self._worker_error: str | None = None
        self._close_when_finished = False
        self._cancel_event: threading.Event | None = None
        self._working = False
        self._inspect_started_at: float | None = None
        self._inspect_stage = "等待后台分析任务启动"
        self._inspect_timer = QTimer(self)
        self._inspect_timer.setInterval(5000)
        self._inspect_timer.timeout.connect(self._inspect_tick)

        self._build_ui()
        self._apply_style()

        last_output = self.settings.value("output_dir", "", str)
        if last_output:
            self.output_edit.setText(last_output)
        if initial_path:
            self.load_file(initial_path)

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(24, 22, 24, 20)
        layout.setSpacing(14)

        title = QLabel("NC Studio")
        title.setObjectName("Title")
        subtitle = QLabel("NetCDF 元数据查看与 GeoTIFF 批量转换")
        subtitle.setObjectName("Subtitle")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        self.drop_zone = DropZone()
        self.drop_zone.fileDropped.connect(self.load_file)
        layout.addWidget(self.drop_zone)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        layout.addWidget(splitter, 1)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 10, 0)
        self.summary_label = QLabel("尚未选择文件")
        self.summary_label.setObjectName("PanelTitle")
        self.variable_list = QListWidget()
        self.variable_list.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        left_layout.addWidget(self.summary_label)
        left_layout.addWidget(self.variable_list, 1)
        splitter.addWidget(left)

        self.tabs = QTabWidget()
        self.variable_table = QTableWidget(0, 6)
        self.variable_table.setHorizontalHeaderLabels(["变量", "单位", "维度", "形状", "可转换", "说明"])
        self.variable_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.variable_table.horizontalHeader().setStretchLastSection(True)
        self.tabs.addTab(self.variable_table, "变量")
        self.space_text = QTextEdit()
        self.space_text.setReadOnly(True)
        self.tabs.addTab(self.space_text, "空间与时间")
        self.attrs_text = QTextEdit()
        self.attrs_text.setReadOnly(True)
        self.tabs.addTab(self.attrs_text, "全局属性")
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.tabs.addTab(self.log_text, "日志")
        splitter.addWidget(self.tabs)
        splitter.setSizes([330, 760])

        bottom = QGridLayout()
        bottom.setHorizontalSpacing(10)
        bottom.setVerticalSpacing(10)
        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText("选择 GeoTIFF 输出目录")
        choose_button = QPushButton("选择")
        choose_button.clicked.connect(self.choose_output)
        self.run_button = QPushButton("运行转换")
        self.run_button.setObjectName("Primary")
        self.run_button.clicked.connect(self.start_export)
        self.cancel_button = QPushButton("取消")
        self.cancel_button.clicked.connect(self.cancel_export)
        self.cancel_button.setEnabled(False)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)

        bottom.addWidget(QLabel("输出目录"), 0, 0)
        bottom.addWidget(self.output_edit, 0, 1)
        bottom.addWidget(choose_button, 0, 2)
        bottom.addWidget(self.run_button, 0, 3)
        bottom.addWidget(self.cancel_button, 0, 4)
        bottom.addWidget(self.progress, 1, 0, 1, 5)
        layout.addLayout(bottom)

    def _apply_style(self) -> None:
        QApplication.instance().setStyleSheet("""
        QMainWindow, QWidget { background: #f5f5f7; color: #1d1d1f; font-family: "Segoe UI", "Microsoft YaHei UI"; font-size: 10.5pt; }
        QLabel#Title { font-size: 28px; font-weight: 700; }
        QLabel#Subtitle { color: #6e6e73; margin-bottom: 4px; }
        QLabel#PanelTitle { font-size: 13px; font-weight: 650; padding: 4px 2px; }
        QListWidget, QTableWidget, QTextEdit, QLineEdit, QTabWidget::pane {
            background: #ffffff; border: 1px solid #e5e5ea; border-radius: 8px;
        }
        QListWidget { padding: 6px; }
        QLineEdit { padding: 8px 10px; }
        QTextEdit { padding: 8px; }
        QPushButton { background: #ffffff; border: 1px solid #d2d2d7; border-radius: 8px; padding: 8px 14px; }
        QPushButton:hover { background: #f2f2f7; }
        QPushButton#Primary { background: #007aff; color: white; border-color: #007aff; font-weight: 650; }
        QPushButton#Primary:hover { background: #0a84ff; }
        QPushButton:disabled { color: #a1a1aa; background: #f1f1f3; }
        QProgressBar { background: #ffffff; border: 1px solid #e5e5ea; border-radius: 7px; height: 14px; text-align: center; }
        QProgressBar::chunk { background: #34c759; border-radius: 6px; }
        QTabBar::tab { padding: 8px 14px; border-radius: 7px; margin-right: 4px; background: #ececf0; }
        QTabBar::tab:selected { background: #ffffff; color: #007aff; }
        QHeaderView::section { background: #fbfbfd; padding: 7px; border: 0; border-bottom: 1px solid #e5e5ea; }
        """)

    def load_file(self, path: str) -> None:
        if self._working:
            self._message("正在处理任务，请先取消或等待完成。")
            return
        self.source_path = str(Path(path).expanduser().absolute())
        self.info = None
        self.analysis_path = None
        self._set_working(True)
        self._inspect_started_at = time.monotonic()
        self._inspect_stage = "等待后台分析任务启动"
        self._inspect_timer.start()
        self.progress.setRange(0, 0)
        self.drop_zone.set_selected(True, f"正在分析：{self.source_path}")
        self.summary_label.setText("正在分析文件...")
        self.variable_list.clear()
        self.variable_table.setRowCount(0)
        self.space_text.clear()
        self.attrs_text.clear()
        self._log(f"分析文件：{self.source_path}")
        worker = InspectWorker(self.source_path)
        worker.status.connect(self._inspect_status)
        self._run_worker(worker, self._inspect_finished)

    def _inspect_finished(self, info: DatasetInfo) -> None:
        if isinstance(info, tuple):
            info, analysis_path = info
            self.analysis_path = analysis_path
        else:
            self.analysis_path = self.source_path
        self._set_working(False)
        self._inspect_timer.stop()
        self._inspect_started_at = None
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFormat("%p%")
        self.info = info
        self.drop_zone.set_selected(True, info.path)
        self.summary_label.setText(f"{Path(info.path).name} · {info.layer_count} 个可导出图层")
        self.variable_list.clear()
        for item in info.variables:
            label = f"{'✓' if item.spatial else '–'} {item.name}"
            if item.spatial:
                label += f"  {item.layer_count} 层"
            entry = QListWidgetItem(label)
            entry.setToolTip(item.reason or item.time_summary)
            self.variable_list.addItem(entry)
        self._fill_variable_table(info)
        self._fill_space_text(info)
        self.attrs_text.setPlainText(json.dumps(info.global_attributes, ensure_ascii=False, indent=2))
        if info.warnings:
            for warning in info.warnings:
                self._log(f"提示：{warning}")
        self._log("元数据分析完成。")

    def _fill_variable_table(self, info: DatasetInfo) -> None:
        self.variable_table.setRowCount(len(info.variables))
        for row, item in enumerate(info.variables):
            values = [
                item.name,
                item.units or "",
                " × ".join(item.dimensions),
                " × ".join(str(v) for v in item.shape),
                "是" if item.spatial else "否",
                item.reason or item.time_summary,
            ]
            for col, value in enumerate(values):
                cell = QTableWidgetItem(value)
                if col == 4 and item.spatial:
                    cell.setForeground(QColor("#188038"))
                elif col == 4:
                    cell.setForeground(QColor("#8a2d2d"))
                self.variable_table.setItem(row, col, cell)

    def _fill_space_text(self, info: DatasetInfo) -> None:
        lines = [f"文件：{info.path}", f"大小：{info.size_bytes:,} bytes", f"维度：{json.dumps(info.dimensions, ensure_ascii=False)}", f"时间：{info.time_summary}", ""]
        for item in info.variables:
            if not item.spatial or item.grid is None:
                continue
            grid = item.grid
            lines.extend([
                f"[{item.name}]",
                f"坐标系：{grid.crs}",
                f"栅格：{grid.width} × {grid.height}",
                f"范围：{grid.bounds}",
                f"经纬度范围：{grid.lonlat_bounds}",
                f"分辨率：{grid.resolution}",
                "",
            ])
        lines.append("坐标变量：")
        lines.append(json.dumps(info.coordinates, ensure_ascii=False, indent=2))
        self.space_text.setPlainText("\n".join(lines))

    def choose_output(self) -> None:
        start = self.output_edit.text() or self.settings.value("output_dir", "", str) or str(Path.home())
        path = QFileDialog.getExistingDirectory(self, "选择输出目录", start)
        if path:
            self.output_edit.setText(path)
            self.settings.setValue("output_dir", path)

    def start_export(self) -> None:
        if self._working:
            return
        if not self.info or not self.source_path:
            self._message("请先拖入或选择 NetCDF 文件。")
            return
        output = self.output_edit.text().strip()
        if not output:
            self.choose_output()
            output = self.output_edit.text().strip()
            if not output:
                return
        variables = [item.name for item in self.info.variables if item.spatial]
        if not variables:
            self._message("没有识别到可转换为空间栅格的变量。")
            return
        self.settings.setValue("output_dir", output)
        self._cancel_event = threading.Event()
        self._set_working(True)
        self.progress.setValue(0)
        self._log(f"开始转换，输出目录：{output}")
        worker = ExportWorker(self.source_path, output, variables, self._cancel_event)
        if self.analysis_path:
            worker.path = self.analysis_path
        worker.progress.connect(self._progress)
        worker.log.connect(self._log)
        self._run_worker(worker, self._export_finished)

    def cancel_export(self) -> None:
        if self._cancel_event:
            self._cancel_event.set()
            self._log("正在取消，已完成的 GeoTIFF 会保留。")
            self.cancel_button.setEnabled(False)

    def _export_finished(self, result: ExportResult) -> None:
        self._set_working(False)
        self.progress.setValue(100 if result.files else self.progress.value())
        for skipped in result.skipped:
            self._log(f"跳过：{skipped}")
        for error in result.errors:
            self._log(f"错误：{error}")
        if result.cancelled:
            self._message(f"转换已取消，已完成 {len(result.files)} 个文件。")
        elif result.errors:
            self._message(f"转换完成，但有 {len(result.errors)} 个错误。")
        else:
            self._message(f"转换完成，共生成 {len(result.files)} 个 GeoTIFF。")
        if result.manifest_path:
            self._log(f"清单：{result.manifest_path}")

    def _progress(self, done: int, total: int, message: str) -> None:
        pct = int(done / total * 100) if total else 0
        self.progress.setValue(max(0, min(100, pct)))
        self.progress.setFormat(f"{done}/{total}  {message}")

    def _run_worker(self, worker: QObject, on_success: Callable[[object], None]) -> None:
        if self._thread is not None:
            raise RuntimeError("后台任务尚未结束。")
        thread = QThread(self)
        self._thread = thread
        self._worker = worker
        self._on_worker_success = on_success
        self._worker_result = None
        self._worker_error = None
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(self._record_worker_result)
        worker.finished.connect(worker.deleteLater)
        worker.finished.connect(thread.quit)
        worker.failed.connect(self._record_worker_error)
        worker.failed.connect(worker.deleteLater)
        worker.failed.connect(thread.quit)
        thread.finished.connect(self._worker_thread_finished)
        thread.finished.connect(thread.deleteLater)
        thread.start()

    @Slot(object)
    def _record_worker_result(self, result: object) -> None:
        self._worker_result = result

    @Slot(str)
    def _record_worker_error(self, message: str) -> None:
        self._worker_error = message

    @Slot()
    def _worker_thread_finished(self) -> None:
        thread = self._thread
        # QThread.finished is emitted just before the native thread performs
        # its final cleanup. Wait for that cleanup before releasing the last
        # Python references; otherwise repeated GUI self-tests can abort.
        if thread is not None:
            thread.wait()
        callback, result, error = self._on_worker_success, self._worker_result, self._worker_error
        self._thread = None
        self._worker = None
        self._on_worker_success = None
        self._worker_result = None
        self._worker_error = None
        self._cancel_event = None
        # Deliver results only after cleanup, so a new task cannot race the
        # previous thread's finished signal and lose its references.
        if self._close_when_finished:
            self._inspect_timer.stop()
            self._set_working(False)
            self.close()
        elif error is not None:
            self._worker_failed(error)
        elif callback is not None:
            callback(result)

    def _worker_failed(self, message: str) -> None:
        self._set_working(False)
        self._inspect_timer.stop()
        self._inspect_started_at = None
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFormat("%p%")
        if self.info is None:
            self.summary_label.setText("文件分析失败，请重新选择文件")
            self.drop_zone.set_selected(False, "文件分析失败，可点击重新选择")
        self._log(f"错误：{message}")
        self._message(message)

    @Slot(str)
    def _inspect_status(self, message: str) -> None:
        self._inspect_stage = message
        self._log(message)

    def _inspect_tick(self) -> None:
        if not self._working or self._inspect_started_at is None:
            return
        elapsed = int(time.monotonic() - self._inspect_started_at)
        if elapsed >= 15:
            self._log(f"分析尚未完成，已用 {elapsed} 秒。当前步骤：{self._inspect_stage}")

    def _set_working(self, working: bool) -> None:
        self._working = working
        self.run_button.setEnabled(not working)
        self.cancel_button.setEnabled(working and self._cancel_event is not None)

    def _log(self, message: str) -> None:
        self.log_text.append(message)

    def _message(self, text: str) -> None:
        QMessageBox.information(self, "NC Studio", text)

    def closeEvent(self, event) -> None:
        if self._thread is not None:
            self._close_when_finished = True
            if self._cancel_event:
                self._cancel_event.set()
            event.ignore()
            self._log("正在等待后台任务结束，随后自动关闭。")
            self.cancel_button.setEnabled(False)
            return
        event.accept()


def run_gui(initial_path: str | None = None) -> int:
    import sys

    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("NC Studio")
    app.setOrganizationName("NCStudio")
    window = MainWindow(initial_path)
    window.show()
    return app.exec()


def _is_unc(path: Path) -> bool:
    text = str(path)
    return text.startswith("\\\\") and not text.startswith("\\\\?\\")


def _local_analysis_path(path: Path, status: Callable[[str], None]) -> Path:
    if not _needs_local_cache(path):
        status("路径无需缓存，直接读取。")
        return path
    stat = path.stat()
    key = sha256(f"{path}|{stat.st_size}|{stat.st_mtime_ns}".encode("utf-8", errors="ignore")).hexdigest()[:20]
    root = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "NCStudio" / "cache"
    root.mkdir(parents=True, exist_ok=True)
    target = root / f"{key}{path.suffix.lower() or '.nc'}"
    if target.is_file() and target.stat().st_size == stat.st_size:
        status(f"使用本地安全缓存读取：{target}")
        return target
    status(f"正在准备本地安全读取路径：{target}")
    if not _is_unc(path):
        try:
            os.link(path, target)
            status("已创建本地安全路径链接，无需复制大文件。")
            return target
        except OSError as error:
            status(f"无法创建安全路径链接，改为复制文件：{error}")
    partial = target.with_suffix(target.suffix + ".partial")
    copied = 0
    last_report = 0.0
    status(f"正在缓存文件到本地安全路径：{target}")
    with path.open("rb") as src, partial.open("wb") as dst:
        while True:
            chunk = src.read(8 * 1024 * 1024)
            if not chunk:
                break
            dst.write(chunk)
            copied += len(chunk)
            now = time.monotonic()
            if now - last_report >= 1.0:
                pct = copied / stat.st_size * 100 if stat.st_size else 0
                status(f"正在缓存文件：{pct:.1f}%")
                last_report = now
    partial.replace(target)
    status("文件缓存完成，开始分析。")
    return target


def _needs_local_cache(path: Path) -> bool:
    if _is_unc(path):
        return True
    try:
        str(path).encode("ascii")
        return False
    except UnicodeEncodeError:
        return True
