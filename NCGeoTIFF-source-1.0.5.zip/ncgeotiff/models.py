"""Plain data contracts shared by the desktop UI and conversion engine."""

from dataclasses import asdict, dataclass, field


@dataclass
class GridInfo:
    crs: str
    x_name: str
    y_name: str
    x_dim: str
    y_dim: str
    width: int
    height: int
    bounds: tuple[float, float, float, float]
    resolution: tuple[float, float]
    lonlat_bounds: tuple[float, float, float, float] | None = None
    warnings: list[str] = field(default_factory=list)


@dataclass
class VariableInfo:
    name: str
    dimensions: tuple[str, ...]
    shape: tuple[int, ...]
    dtype: str
    units: str
    spatial: bool
    reason: str = ""
    layer_count: int = 0
    time_summary: str = "无时间维度"
    grid: GridInfo | None = None
    attributes: dict[str, str] = field(default_factory=dict)


@dataclass
class DatasetInfo:
    path: str
    size_bytes: int
    dimensions: dict[str, int]
    global_attributes: dict[str, str]
    variables: list[VariableInfo]
    coordinates: dict[str, dict] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    time_summary: str = "无时间坐标"

    @property
    def layer_count(self) -> int:
        return sum(v.layer_count for v in self.variables if v.spatial)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ExportResult:
    files: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    cancelled: bool = False
    manifest_path: str | None = None
