"""Command line and desktop entry points for NC Studio."""
from __future__ import annotations

import argparse
from dataclasses import asdict, is_dataclass
import json
from pathlib import Path
import signal
import sys
import threading
from typing import Any

from . import __version__
from .engine import NetCDFError, export_file, inspect_file


def _json_default(value: Any) -> Any:
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, Path):
        return str(value)
    return str(value)


def _write_report(path: str | None, payload: Any) -> None:
    if not path:
        return
    target = Path(path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=_json_default),
        encoding="utf-8",
    )


def _print_json(payload: Any) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2, default=_json_default)
    if sys.stdout:
        print(text)


def _run_gui(path: str | None = None) -> int:
    from .gui import run_gui

    return run_gui(path)


def _self_test(report: str | None = None) -> int:
    from .selftest import run_self_test

    payload = run_self_test()
    _write_report(report, payload)
    if payload.get("ok"):
        _print_json(payload)
        return 0
    _print_json(payload)
    return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="NCStudio",
        description="Inspect CF NetCDF files and convert spatial variables to GeoTIFF.",
    )
    parser.add_argument("--version", action="version", version=f"NC Studio {__version__}")
    parser.add_argument("--self-test", action="store_true", help="Run a packaged smoke test.")
    parser.add_argument("--gui-self-test", nargs="?", const="", metavar="FILE", help="Test actual GUI loading; optionally inspect a supplied NetCDF file.")
    parser.add_argument("--report", help="Write JSON report for inspect, convert, or self-test.")

    subparsers = parser.add_subparsers(dest="command")

    gui = subparsers.add_parser("gui", help="Start the desktop app.")
    gui.add_argument("file", nargs="?", help="Optional NetCDF file to open.")

    inspect = subparsers.add_parser("inspect", help="Inspect a NetCDF file.")
    inspect.add_argument("file")
    inspect.add_argument("--report")

    convert = subparsers.add_parser("convert", help="Convert spatial variables to GeoTIFF.")
    convert.add_argument("file")
    convert.add_argument("output")
    convert.add_argument("--variable", "-v", action="append", help="Variable to export. Repeatable.")
    convert.add_argument("--report")

    return parser


def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        if stream and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8")
            except Exception:
                pass
    if argv is None:
        argv = sys.argv[1:]
    commands = {"gui", "inspect", "convert"}
    first_argument = argv[0] if argv and not argv[0].startswith("-") else None
    if first_argument and first_argument not in commands and Path(first_argument).suffix.lower() in {".nc", ".nc4", ".cdf"}:
        return _run_gui(first_argument)

    args = build_parser().parse_args(argv)

    if args.self_test:
        return _self_test(args.report)

    if args.gui_self_test is not None:
        from .selftest import run_gui_test

        payload = run_gui_test(args.gui_self_test or None)
        _write_report(args.report, payload)
        _print_json(payload)
        return 0 if payload.get("ok") else 1

    try:
        if args.command == "inspect":
            info = inspect_file(args.file)
            payload = asdict(info)
            _write_report(args.report, payload)
            _print_json(payload)
            return 0

        if args.command == "convert":
            cancel = threading.Event()
            previous = signal.getsignal(signal.SIGINT)

            def _cancel(_signum, _frame):
                cancel.set()

            signal.signal(signal.SIGINT, _cancel)
            try:
                result = export_file(
                    args.file,
                    args.output,
                    variable_names=args.variable,
                    cancel=cancel.is_set,
                    progress=lambda done, total, message: print(f"[{done}/{total}] {message}") if sys.stdout else None,
                    log=lambda message: print(message) if sys.stdout else None,
                )
            finally:
                signal.signal(signal.SIGINT, previous)
            payload = asdict(result)
            _write_report(args.report, payload)
            _print_json(payload)
            return 2 if result.cancelled else (1 if result.errors else 0)

        if args.command == "gui":
            return _run_gui(args.file)

        return _run_gui(None)
    except NetCDFError as exc:
        if sys.stderr:
            print(str(exc), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        if sys.stderr:
            print("已取消。", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
