"""NC Studio — NetCDF to GeoTIFF desktop converter."""

__version__ = "1.0.5"


