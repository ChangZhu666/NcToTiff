"""Resolve data shipped with this bundle without changing system settings."""

import os
import sys
from pathlib import Path


if getattr(sys, "frozen", False):
    bundle = Path(sys._MEIPASS)
    if hasattr(os, "add_dll_directory"):
        for directory in (
            bundle,
            bundle / "PySide6",
            bundle / "shiboken6",
            bundle / "numpy.libs",
            bundle / "rasterio.libs",
            bundle / "netcdf4.libs",
            bundle / "pyproj.libs",
            bundle / "pandas.libs",
        ):
            if directory.is_dir():
                os.add_dll_directory(str(directory))
    # Windows wheels store GDAL and PROJ data beneath their own packages.
    # Only set an application-process variable when its bundled data exists.
    gdal = bundle / "rasterio" / "gdal_data"
    if gdal.is_dir():
        os.environ["GDAL_DATA"] = str(gdal)
    for proj in (
        bundle / "pyproj" / "proj_dir" / "share" / "proj",
        bundle / "rasterio" / "proj_data",
    ):
        if (proj / "proj.db").is_file():
            os.environ["PROJ_DATA"] = str(proj)
            os.environ["PROJ_LIB"] = str(proj)
            break
